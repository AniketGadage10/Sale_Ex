package com.saleex.admin.invitation.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class InviteResponseDto {
    private String msg;

    private Long id;

    // private Invitation user;

}
