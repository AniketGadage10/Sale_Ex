package com.saleex.admin.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.saleex.admin.user.entity.Role;


public interface RoleRepository extends JpaRepository<Role, Long> {
    Role findByName(String role);

}