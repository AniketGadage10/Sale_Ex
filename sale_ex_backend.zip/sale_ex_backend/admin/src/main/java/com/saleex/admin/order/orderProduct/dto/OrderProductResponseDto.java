package com.saleex.admin.order.orderProduct.dto;

import com.saleex.admin.product.dto.AddProductResponseDto;
import com.saleex.admin.user.dto.UserResponseDto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.List;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class OrderProductResponseDto {

    private List<AddProductResponseDto> product;

    private UserResponseDto seller;

    private UserResponseDto customer;

    private int quantity;
}
