package com.saleex.admin.user.dto;

import lombok.Getter;

@Getter
public class AddressDto {

    private String country;

    private String state;

    private String city;

    private String zipcode;

    private String fullAddress;

}
