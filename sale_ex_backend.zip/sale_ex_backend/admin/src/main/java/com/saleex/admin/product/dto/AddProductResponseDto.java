package com.saleex.admin.product.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import java.util.*;

import com.saleex.admin.common.enums.ProductType;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class AddProductResponseDto {
    private long productId;
    private String productName;
    private String description;
    private int quantity;
    private double price;
    private List<String> picture;
    private ProductType productType;
    private long addedByUserId;
}
