package com.saleex.admin.user.entity;

import org.hibernate.annotations.UpdateTimestamp;

import com.saleex.admin.entity.BaseEntity;
import com.saleex.admin.invitation.entity.Invitation;
import com.saleex.admin.notification.entity.Messages;
import com.saleex.admin.notification.entity.Notification;
import com.saleex.admin.order.entity.Order;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.*;

@Entity
@Table(name = "users")
@Setter
@Getter
@NoArgsConstructor
public class User extends BaseEntity {

    @NotBlank(message = "First name is required")
    @Size(max = 100, message = "First name cannot be longer than 100 characters")
    @Column(name = "first_name")
    private String fname;

    @NotBlank(message = "Last name is required")
    @Size(max = 100, message = "Last name cannot be longer than 100 characters")
    @Column(name = "last_name")
    private String lname;

    @Column(name = "user_profile")
    private byte[] userProfile;

    @NotBlank(message = "Email is required")
    @Email(message = "Invalid email format")
    @Size(max = 255, message = "Email cannot be longer than 255 characters")
    @Column(name = "email", unique = true)
    private String email;

    @NotBlank(message = "Password is required")
    @Size(min = 6, max = 255, message = "Password must be between 6 and 255 characters")
    @Column(name = "password")
    private String password;

    @NotBlank(message = "Contact is required")
    @Size(max = 12, message = "Contact cannot be longer than 12 characters")
    @Column(name = "contact")
    private String contact;

    private String address;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "joining_date", updatable = false)
    private Date joiningDate;

    @OneToMany(mappedBy = "user", fetch = FetchType.EAGER)
    private Set<UserRole> userRoles;

    @OneToMany(mappedBy = "user")
    private List<Notification> notifications;

    @OneToMany(mappedBy = "inviter")
    private List<Invitation> sentInvitations;

    @OneToMany(mappedBy = "customer")
    private List<Order> orders;

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Messages> messages;

    @Column(name = "invitedBy")
    private Long invitedBy;

}
