package com.saleex.admin.common.constants;

public final class Constants {

    public static final String BASE_URI = "/api/v1";

    public static final String USER_URI = BASE_URI + "/user";

    public static final String ORDER_URI = BASE_URI + "/order";

    public static final String PRODUCT_URI = BASE_URI + "/product";

    public static final String INVITATION_URI = BASE_URI + "/invitation";

    public static final String AUTH_URI = BASE_URI + "/auth";

    public static final String NOTIFICATION_URI = BASE_URI + "/notification";

    public static final String REQUEST_URI = BASE_URI + "/request";

    public static final String ID = "/{id}";

    public static final String CUSTOMER_URI = "/customer";

    public static final String STATUS = "/status";

}
