package com.saleex.admin.product.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.saleex.admin.common.enums.ProductType;
import com.saleex.admin.product.dto.AddProductRequestDto;
import com.saleex.admin.product.dto.AddProductResponseDto;
import com.saleex.admin.product.dto.ProductDto;
import com.saleex.admin.product.dto.ProductDtoForMobile;

public interface ProductService {
    AddProductResponseDto addProduct(AddProductRequestDto addProductRequestDTO);

    ProductDto getProductById(Long productId);

    Page<ProductDto> getAllProducts(Pageable pageable);

    ProductDto updateProduct(Long productId, AddProductRequestDto updateProductRequestDto);

    Page<ProductDto> getProductsByType(ProductType productType, Pageable pageable);

    Page<AddProductResponseDto> filterProductsByName(String name, int pageNumber, int sizeNumber);

    ProductDto deleteProduct(Long id);

    ProductDtoForMobile productDetailsForMobile();
}
