package com.saleex.admin.invitation.controller;

import static com.saleex.admin.common.constants.Constants.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.saleex.admin.common.model.ResponseEntity;
import com.saleex.admin.invitation.dto.InviteRequestDto;
import com.saleex.admin.invitation.dto.InviteResponseDto;
import com.saleex.admin.invitation.service.InvitationService;

@RestController
@RequestMapping(INVITATION_URI)
@CrossOrigin("*")
public class InvitationController {

    @Autowired
    private InvitationService inviteService;

    @PostMapping(ID)
    // @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<InviteResponseDto> inviteByAdmin(@PathVariable Long id,
            @RequestBody InviteRequestDto request) {
        InviteResponseDto user = inviteService.inviteByAdmin(id, request);
        return (user != null) ? ResponseEntity.success(user) : ResponseEntity.error("Invitee not found");
    }

}
