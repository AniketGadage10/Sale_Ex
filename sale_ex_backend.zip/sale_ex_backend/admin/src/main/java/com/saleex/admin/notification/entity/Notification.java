package com.saleex.admin.notification.entity;

import lombok.*;
import jakarta.persistence.*;
import java.util.Date;

import org.hibernate.annotations.UpdateTimestamp;

import com.saleex.admin.entity.BaseEntity;
import com.saleex.admin.user.entity.User;

@Entity
@Table(name = "notifications")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class Notification extends BaseEntity {

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @UpdateTimestamp
    @Column(name = "timestamp")
    @Temporal(TemporalType.TIMESTAMP)
    private Date timestamp;

    @Column(name = "firebase_token")
    private String firebaseToken;
}
