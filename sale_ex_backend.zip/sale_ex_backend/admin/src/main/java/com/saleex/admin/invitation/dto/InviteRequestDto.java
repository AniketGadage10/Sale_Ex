package com.saleex.admin.invitation.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class InviteRequestDto {
    private String fName;

    private String lName;

    private String inviteeEmail;

    private String inviteeRole;
}
