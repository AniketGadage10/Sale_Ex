package com.saleex.admin.notification.exception;

public class NotificationNotFoundException extends RuntimeException {
    public NotificationNotFoundException(String msg) {
        super(msg);
    }

}
