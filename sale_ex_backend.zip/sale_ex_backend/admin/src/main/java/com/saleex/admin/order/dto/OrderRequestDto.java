package com.saleex.admin.order.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.*;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class OrderRequestDto {
    private BigDecimal totalAmount;

    private Long customerId;

    private Map<Long, Integer> product_quantity;

    private String status;
}
