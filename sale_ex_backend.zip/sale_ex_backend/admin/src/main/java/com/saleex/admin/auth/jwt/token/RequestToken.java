package com.saleex.admin.auth.jwt.token;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Getter
@AllArgsConstructor
public class RequestToken {
    private String refToken;
}
