package com.saleex.admin.user.service;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;

import com.saleex.admin.auth.jwt.token.RequestToken;
import com.saleex.admin.auth.jwt.token.TokenDto;
import com.saleex.admin.user.dto.AdminDto;
import com.saleex.admin.user.dto.AuthUserDto;
import com.saleex.admin.user.dto.CustomerResponseDto;
import com.saleex.admin.user.dto.StatusDto;
import com.saleex.admin.user.dto.UserFullDetails;
import com.saleex.admin.user.dto.UserRequestDto;
import com.saleex.admin.user.dto.UserResponseDto;

import io.jsonwebtoken.io.IOException;

public interface UserService {

    List<UserResponseDto> listOfUsers();

    UserResponseDto createUser(AdminDto user) throws IOException, java.io.IOException;

    UserResponseDto updateUser(Long id, UserRequestDto user) throws java.io.IOException;

    UserResponseDto deleteUser(Long id);

    UserFullDetails getUserById(Long id);

    TokenDto userLogin(AuthUserDto userData);

    String generateTokenFromRefreshToken(RequestToken refreshToken);

    Page<UserResponseDto> filterByDate(Date startDate, Date endDate, int page, int size);

    Page<UserResponseDto> listOfUsersByPagination(Integer pageNumber, Integer pageSize);

    Page<UserResponseDto> filterByRoles(String role, int page, int size);

    Page<UserResponseDto> filterForCustomer(String role, int page, int size);

    Page<UserResponseDto> listOfUserByStatus(Integer pageNumber, Integer pageSize, String status);

    StatusDto changeStatus(String status, Long id);

    Page<UserResponseDto> findEntitiesByNameWithPagination(String name, int page, int size);

    Page<CustomerResponseDto> customerList(int page, int size);

}
