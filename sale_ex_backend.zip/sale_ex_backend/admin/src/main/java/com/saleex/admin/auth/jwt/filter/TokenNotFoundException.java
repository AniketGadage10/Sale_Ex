package com.saleex.admin.auth.jwt.filter;

public class TokenNotFoundException extends RuntimeException {

    public TokenNotFoundException(String msg) {

        super(msg);
    }

}