package com.saleex.admin.user.entity;
// package com.saleex.admin.entity;

// import jakarta.persistence.*;
// import lombok.Getter;
// import lombok.NoArgsConstructor;
// import lombok.Setter;

// @Entity
// @Table(name = "address")
// @Setter
// @Getter
// @NoArgsConstructor
// public class Address extends BaseEntity {

// @Column(name = "country")
// private String country;

// @Column(name = "state")
// private String state;

// @Column(name = "city")
// private String city;

// @Column(name = "zipcode")
// private String zipcode;

// @Column(name = "full_address")
// private String fullAddress;

// @OneToOne
// @JoinColumn(name = "user_id")
// private User user;

// }
