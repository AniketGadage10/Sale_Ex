package com.saleex.admin.order.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.*;

import com.saleex.admin.product.dto.ProductDto;
import com.saleex.admin.product.dto.ProductResponseDto;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class ActiveOrderDetails {
    private int cancelledOrders;
    private int completedOrders;
    private int outgoingOrders;
    private int totalOrders;
    private double cancelledPercentage;
    private double completedPercentage;
    private double outgoingPercentage;
    private double totalPercentage;
    private double totalCost;
    private List<ProductDto> topSellingProducts;
    private Map<String, ProductResponseDto> todaysOrders;
    private List<ProductDto> last7DayList;

}
