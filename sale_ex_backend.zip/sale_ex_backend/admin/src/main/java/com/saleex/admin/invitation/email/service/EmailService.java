package com.saleex.admin.invitation.email.service;

import com.saleex.admin.invitation.dto.InviteRequestDto;
import com.saleex.admin.order.dto.AllOrderDetails;

public interface EmailService {
    boolean sendInvitationMail(InviteRequestDto user);

    void sendOrderConfirmationEmail(AllOrderDetails orderResponse, String recipientEmail);

}
