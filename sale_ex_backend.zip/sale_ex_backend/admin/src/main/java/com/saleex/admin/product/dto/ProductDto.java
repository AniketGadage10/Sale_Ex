package com.saleex.admin.product.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

import com.saleex.admin.common.enums.ProductType;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ProductDto {
    private Long productId;
    private String productName;
    private String description;
    private int quantity;
    private BigDecimal price;
    private List<String> picture;
    private ProductType productType;
    private long addedByUserId;
}
