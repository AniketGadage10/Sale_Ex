// package com.saleex.admin.log;


// import java.io.File;
// import java.io.FileWriter;
// import java.io.IOException;
// import org.springframework.beans.factory.annotation.Value;
// import org.springframework.stereotype.Component;

// import com.saleex.admin.common.enums.LogLevel;

// @Component
// public class SaleExLogger {
//     @Value("${log.file.general}")
//     String generalLogFilePath;
//     @Value("${log.file.warning}")
//     String warningLogFilePath;
//     @Value("${log.file.error}")
//     String errorLogFilePath;

//     public void log(LogLevel logLevel, String message) {
//         String path;
//         switch (logLevel) {
//             case GENERAL:
//                 path = generalLogFilePath;
//                 break;
//             case WARNINGS:
//                 path = warningLogFilePath;
//                 break;
//             case ERROR:
//                 path = errorLogFilePath;
//                 break;
//             default:
//                 path = generalLogFilePath;
//                 break;
//         }// end of switch
//         File file = new File(path);
//         if (!file.exists()) {
//             try {
//                 file.getParentFile().mkdirs();
//                 file.createNewFile();
//             } catch (IOException e) {
//                 System.out.println("inside first catch ");
//                 e.printStackTrace();
//                 return;
//             }
//         }
//         // now file exist
//         try (FileWriter writer = new FileWriter(file, true)) {
//             writer.append(message);
//             writer.append('\n');
//         } catch (Exception e) {
//             System.out.println("inside second catch ");
//             e.printStackTrace();
//             return;
//         }
//     } // end of log
// }