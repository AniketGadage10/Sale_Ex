package com.saleex.admin.common.enums;

public enum EntityStatus {
    INVITED, ACTIVE, DEACTIVATE;

}
