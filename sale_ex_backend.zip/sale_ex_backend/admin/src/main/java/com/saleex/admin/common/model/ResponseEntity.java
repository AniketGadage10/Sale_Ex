package com.saleex.admin.common.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.Date;

//Author :  Sumedh Shingade

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ResponseEntity<T> {
    private Integer code;
    private String message;
    private T data;
    private Date timestamp;

    public static <T> ResponseEntity<T> success(T data) {
        return new ResponseEntity<>(200, "Success", data, new Date());
    }

    public static <T> ResponseEntity<T> error(String message) {
        return new ResponseEntity<>(500, message, null, new Date());
    }

    public static <T> ResponseEntity<T> noContent() {
        return new ResponseEntity<>(204, "No Content", null, new Date());
    }
}
