package com.saleex.admin.notification.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static com.saleex.admin.common.constants.Constants.*;

import java.util.*;

import com.saleex.admin.common.model.ResponseEntity;
import com.saleex.admin.notification.dto.NotificationListDto;
import com.saleex.admin.notification.service.MessageService;

@RestController
@RequestMapping(NOTIFICATION_URI)
public class NotifcationController {

    @Autowired
    private MessageService msgService;

    // @PreAuthorize("isAuthenticated()")
    @GetMapping(ID)
    public ResponseEntity<List<NotificationListDto>> getNotificationListById(@PathVariable Long id) {
        List<NotificationListDto> list = msgService.getNotificationList(id);
        return (list != null) ? ResponseEntity.success(list) : ResponseEntity.error("No Notifications");

    }

}
