package com.saleex.admin.order.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import static com.saleex.admin.common.constants.Constants.*;

import java.util.*;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;

import com.saleex.admin.common.model.ResponseEntity;
import com.saleex.admin.order.dto.ActiveOrderDetails;
import com.saleex.admin.order.dto.AllOrderDetails;
import com.saleex.admin.order.dto.ChangeStatusDto;
import com.saleex.admin.order.dto.OrderRequestDto;
import com.saleex.admin.order.dto.OrderResponseDto;
import com.saleex.admin.order.dto.OrderedProductList;
import com.saleex.admin.order.orderService.OrderService;

@RestController
@RequestMapping(ORDER_URI)
@CrossOrigin("*")
public class OrderController {

    @Autowired
    private OrderService orderService;

    // seller id
    @PreAuthorize("hasAuthority('SELLER')")
    @PostMapping(ID)

    public ResponseEntity<AllOrderDetails> cerateOrder(@PathVariable Long id,
            @RequestBody OrderRequestDto productOrder) {
        AllOrderDetails response = orderService.createOrder(id, productOrder);
        return (response != null) ? ResponseEntity.success(response) : ResponseEntity.error("Order not found");

    }

    // orderid
    @PreAuthorize("hasAuthority('SELLER')")
    @PutMapping(ID)
    public ResponseEntity<AllOrderDetails> updateOrder(
            @PathVariable Long id,
            @RequestParam Long sellerId,
            @RequestBody OrderRequestDto orderDetails) {

        AllOrderDetails updatedOrder = orderService.updateOrder(id, sellerId, orderDetails);

        return (updatedOrder != null) ? ResponseEntity.success(updatedOrder) : ResponseEntity.error("Order not found");

    }

    @PreAuthorize("hasAuthority('ADMIN') || hasAuthority('SELLER')")
    @GetMapping
    public ResponseEntity<List<OrderedProductList>> orderedProductList() {
        List<OrderedProductList> list = orderService.orderedProductList();
        return (list != null) ? ResponseEntity.success(list) : ResponseEntity.error("Order not found");

    }

    @PreAuthorize("hasAuthority('SELLER')")
    @DeleteMapping(ID)
    public ResponseEntity<OrderResponseDto> deleteOrder(@PathVariable Long id) {
        OrderResponseDto order = orderService.deleteOrder(id);
        return (order != null) ? ResponseEntity.success(order) : ResponseEntity.error("Order not found");

    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping(STATUS + "/{status}")
    public ResponseEntity<Page<OrderedProductList>> getOrdersByStatus(
            @PathVariable String status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        Page<OrderedProductList> orderedProductPage = orderService.ordersByStatus(status, page, size);
        return (orderedProductPage != null) ? ResponseEntity.success(
                orderedProductPage) : ResponseEntity.error("Order not found");

    }

    @GetMapping("/details")
    public ResponseEntity<ActiveOrderDetails> orderDetails() {

        ActiveOrderDetails details = orderService.orderDetails();
        return (details != null) ? ResponseEntity.success(details) : ResponseEntity.error("Order not found");
    }

    @PostMapping(STATUS + ID)
    public ResponseEntity<AllOrderDetails> changeStatus(@RequestBody ChangeStatusDto statusDetails) {

        AllOrderDetails details = orderService.changeOrderStatus(statusDetails);
        return (details != null) ? ResponseEntity.success(details) : ResponseEntity.error("Order not found");
    }

    @GetMapping(ORDER_URI + ID)
    public ResponseEntity<Page<AllOrderDetails>> findByNameWithPagination(@PathVariable Long id,
            @RequestParam(value = "pageNumber", defaultValue = "0", required = false) Integer pageNumber,
            @RequestParam(value = "pageSize", defaultValue = "10", required = false) Integer pageSize) {
        Page<AllOrderDetails> response = orderService.filterProductsById(id,
                pageNumber, pageSize);

        return (response != null) ? ResponseEntity.success(response) : ResponseEntity.error("User page not found");

    }

}