package com.saleex.admin.order.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.saleex.admin.common.enums.OrdersEnum;
import com.saleex.admin.order.entity.Order;

import org.springframework.data.domain.Pageable;
import java.util.List;
import java.util.Date;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {

    Page<Order> findByStatus(OrdersEnum status, Pageable pageable);

    List<Order> findByOrderStatus(OrdersEnum orderStatus);

    @Query("SELECT o FROM Order o WHERE FUNCTION('DATE', o.creationDate) = CURRENT_DATE")
    List<Order> findTodaysOrders();

    List<Order> findByOrderStatusAndDateOfOrderBetween(OrdersEnum status, Date startDate, Date endDate);

    List<Order> findByDateOfOrderBetween(Date lastMonth, Date startMonth);

    @Query("SELECT o FROM Order o WHERE CAST(o.id AS STRING) LIKE CONCAT(:orderId, '%')")
    Page<Order> findByIdWithPaginationPage(@Param("orderId") String orderId, Pageable pageable);

    List<Order> findByCustomerId(Long customerId);

}
