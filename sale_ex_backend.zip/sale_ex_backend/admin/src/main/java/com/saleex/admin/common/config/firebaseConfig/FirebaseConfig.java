
// package com.saleex.admin.common.config.firebaseConfig;

// import com.google.auth.oauth2.GoogleCredentials;
// import com.google.firebase.FirebaseApp;
// import com.google.firebase.FirebaseOptions;
// import org.springframework.context.annotation.Bean;
// import org.springframework.context.annotation.Configuration;
// import java.io.FileInputStream;
// import java.io.IOException;

// @Configuration
// public class FirebaseConfig {
//     // private static final String FIREBASE_APP_NAME = "Sale-Ex";
//     private static boolean firebaseInitialized = false;

//     @Bean
//     FirebaseApp initializeFirebaseApp() throws IOException {
//         // List<FirebaseApp> firebaseApps = FirebaseApp.getApps();
//         if (!firebaseInitialized) {
//             FileInputStream serviceAccount = new FileInputStream(
//                     "/home/mindbowser/Documents/Sale_Ex/sale-ex-firebase-adminsdk-qpiev-2ec387f76e .json");
//             // "/home/mindbowser/Documents/Sale_Ex/sale_ex_backend/chat-c2d1d-firebase-adminsdk-ra4so-85c9adadfd.json");
//             FirebaseOptions options = FirebaseOptions.builder()
//                     .setCredentials(GoogleCredentials.fromStream(serviceAccount))
//                     .build();
//             System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>.");
//             FirebaseApp firebaseApp = FirebaseApp.initializeApp(options);
//             System.out.println("Firebase app initialized with name: " + firebaseApp.getName());
//             firebaseInitialized = true;
//         }
//         return FirebaseApp.getInstance();
//     }

// }
