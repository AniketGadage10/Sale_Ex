package com.saleex.admin.common.enums;

public enum LogLevel {
    GENERAL, WARNINGS, ERROR;
}