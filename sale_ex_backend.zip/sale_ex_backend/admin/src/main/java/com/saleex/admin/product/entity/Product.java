package com.saleex.admin.product.entity;

import lombok.*;

import com.saleex.admin.common.enums.ProductType;
import com.saleex.admin.entity.BaseEntity;
import com.saleex.admin.user.entity.User;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.util.List;

@Entity
@Table(name = "products")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Product extends BaseEntity {

    @Column(name = "product_name")
    private String productName;

    @Column(name = "description")
    private String description;

    @Column(name = "quantity")
    private int quantity;

    @Column(name = "fixed_quantity")
    private int fixedQuantity;

    @Column(name = "price")
    private BigDecimal price;

    @ElementCollection
    @CollectionTable(name = "product_images", joinColumns = @JoinColumn(name = "product_id"))
    @Column(name = "image_url")
    private List<byte[]> picture;

    @Column(name = "product_type")
    private ProductType productType;

    @ManyToOne
    @JoinColumn(name = "admin_id")
    private User addedBy;

}
