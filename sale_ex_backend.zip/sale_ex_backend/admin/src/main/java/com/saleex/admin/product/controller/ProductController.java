package com.saleex.admin.product.controller;

import com.saleex.admin.common.enums.ProductType;
import com.saleex.admin.common.model.ResponseEntity;
import com.saleex.admin.product.dto.AddProductRequestDto;
import com.saleex.admin.product.dto.AddProductResponseDto;
import com.saleex.admin.product.dto.ProductDto;
import com.saleex.admin.product.dto.ProductDtoForMobile;
import com.saleex.admin.product.service.ProductService;

import jakarta.validation.Valid;

import static com.saleex.admin.common.constants.Constants.*;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(PRODUCT_URI)
@CrossOrigin("*")
public class ProductController {

    private final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    @PreAuthorize("isAuthenticated()")
    @PostMapping
    public ResponseEntity<AddProductResponseDto> addProduct(
            @Valid @RequestBody AddProductRequestDto addProductRequestDTO) {
        AddProductResponseDto responseDTO = productService.addProduct(addProductRequestDTO);
        return (responseDTO != null) ? ResponseEntity.success(responseDTO) : ResponseEntity.error("Product not added");
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping(ID)
    public ResponseEntity<ProductDto> getProductById(@PathVariable Long id) {
        ProductDto productDto = productService.getProductById(id);
        return (productDto != null) ? ResponseEntity.success(productDto) : ResponseEntity.error("Product not found");

    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping
    public ResponseEntity<Page<ProductDto>> getAllProducts(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false, defaultValue = "productName,asc") String sort) {

        String[] sortParams = sort.split(",");
        Sort.Direction direction = Sort.Direction.ASC;
        if (sortParams.length > 1 && sortParams[1].equalsIgnoreCase("desc")) {
            direction = Sort.Direction.DESC;
        }

        Pageable pageable = PageRequest.of(page, size, Sort.by(direction, sortParams[0]));

        Page<ProductDto> products = productService.getAllProducts(pageable);
        return (products != null) ? ResponseEntity.success(products) : ResponseEntity.error("Product not found");

    }

    @PreAuthorize("isAuthenticated()")
    @PatchMapping(ID)
    public ResponseEntity<ProductDto> updateProduct(
            @PathVariable Long id,
            @RequestBody AddProductRequestDto updateProductRequestDto) {

        ProductDto updatedProduct = productService.updateProduct(id, updateProductRequestDto);
        return (updatedProduct != null) ? ResponseEntity.success(
                updatedProduct) : ResponseEntity.error("Product not updated");

    }

    @PreAuthorize("isAuthenticated()")
    @DeleteMapping(ID)
    public ResponseEntity<ProductDto> deleteProduct(
            @PathVariable Long id) {

        ProductDto deletedProduct = productService.deleteProduct(id);
        return (deletedProduct != null) ? ResponseEntity.success(
                deletedProduct) : ResponseEntity.error("Product not updated");

    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/details")
    public ResponseEntity<ProductDtoForMobile> productDetails() {

        ProductDtoForMobile details = productService.productDetailsForMobile();
        return (details != null) ? ResponseEntity.success(
                details) : ResponseEntity.error("Product not updated");

    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/type")
    public ResponseEntity<Page<ProductDto>> getProductsByType(
            @RequestParam(required = false, defaultValue = "ELECTRONICS") ProductType productType,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "productName,asc") String sort) {

        String[] sortParams = sort.split(",");
        Sort.Direction direction = Sort.Direction.ASC;
        if (sortParams.length > 1 && sortParams[1].equalsIgnoreCase("desc")) {
            direction = Sort.Direction.DESC;
        }

        Pageable pageable = PageRequest.of(page, size, Sort.by(direction, sortParams[0]));

        Page<ProductDto> products = productService.getProductsByType(productType, pageable);
        return (products != null) ? ResponseEntity.success(
                products) : ResponseEntity.error("Product not found");

    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/productName/{productName}")
    public ResponseEntity<Page<AddProductResponseDto>> findByNameWithPagination(@PathVariable String productName,
            @RequestParam(value = "pageNumber", defaultValue = "0", required = false) Integer pageNumber,
            @RequestParam(value = "pageSize", defaultValue = "10", required = false) Integer pageSize) {
        Page<AddProductResponseDto> response = productService.filterProductsByName(productName, pageNumber, pageSize);

        return (response != null) ? ResponseEntity.success(response) : ResponseEntity.error("User page not found");

    }
}