package com.saleex.admin.notification.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.saleex.admin.notification.dto.NotificationListDto;
import com.saleex.admin.notification.entity.Messages;
import com.saleex.admin.notification.repository.MessageRepository;

import jakarta.transaction.Transactional;

import java.util.*;

@Service
public class MessageServiceImpl implements MessageService {

    @Autowired
    private MessageRepository messasgeRepo;

    @Transactional
    @Override
    public List<NotificationListDto> getNotificationList(Long id) {

        List<NotificationListDto> list = new ArrayList<>();

        List<Messages> msgList = messasgeRepo.findByUserId(id);

        for (Messages msg : msgList) {
            NotificationListDto notify = new NotificationListDto();
            notify.setOrder_state(msg.getOrder_state().name());
            notify.setTime(msg.getUpdationDate());
            notify.setId(msg.getId());
            list.add(notify);
        }

        return list;

    }

}
