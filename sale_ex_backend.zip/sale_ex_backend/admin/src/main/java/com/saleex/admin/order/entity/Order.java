
package com.saleex.admin.order.entity;

import lombok.*;
import jakarta.persistence.*;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.hibernate.annotations.CreationTimestamp;

import com.saleex.admin.common.enums.OrdersEnum;
import com.saleex.admin.entity.BaseEntity;
import com.saleex.admin.user.entity.User;

@Entity
@Table(name = "orders")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class Order extends BaseEntity {

    @Column(name = "date_of_order")
    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateOfOrder;

    @Column(name = "total_amount")
    private BigDecimal totalAmount;

    @Column(name = "order_status")
    private OrdersEnum orderStatus;

    @OneToMany(mappedBy = "order")
    private List<OrderProducts> orderProducts;

    @ManyToMany
    @JoinTable(name = "order_seller", joinColumns = @JoinColumn(name = "order_id"), inverseJoinColumns = @JoinColumn(name = "seller_id"))
    private List<User> sellers;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User customer;
}