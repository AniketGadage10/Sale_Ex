// package com.saleex.admin.log;

// import java.time.LocalDateTime;
// import org.aspectj.lang.annotation.AfterThrowing;
// import org.aspectj.lang.annotation.Aspect;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.stereotype.Component;

// import com.saleex.admin.common.enums.LogLevel;

// @Aspect
// @Component
// public class LogAOP {
//     @Autowired
//     SaleExLogger logger;

//     // @AfterThrowing(pointcut = "execution(*
//     // com.saleex.admin.user.controller.*.*(..))", throwing = "ex")
//     // public void errorLogging(Exception ex) {
//     // logger.log(LogLevel.ERROR, ex.getMessage()+" "+LocalDateTime.now());
//     // }
//     @AfterThrowing(pointcut = "execution(* com.saleex.admin.user.controller.*.*(..))", throwing = "ex")
//     public void errorLoggingForUserControllers(Exception ex) {
//         logger.log(LogLevel.ERROR, ex.getMessage() + "  " + LocalDateTime.now());
//     }

//     // Pointcut for invitation-related controllers
//     @AfterThrowing(pointcut = "execution(* com.saleex.admin.invitation.controller.*.*(..))", throwing = "ex")
//     public void errorLoggingForInvitationControllers(Exception ex) {
//         logger.log(LogLevel.ERROR, ex.getMessage() + "  " + LocalDateTime.now());
//     }

//     // Pointcut for product-related controllers
//     @AfterThrowing(pointcut = "execution(* com.saleex.admin.product.controller.*.*(..))", throwing = "ex")
//     public void errorLoggingForProductControllers(Exception ex) {
//         logger.log(LogLevel.ERROR, ex.getMessage() + "  " + LocalDateTime.now());
//     }

//     // Pointcut for order-related controllers
//     @AfterThrowing(pointcut = "execution(* com.saleex.admin.order.controller.*.*(..))", throwing = "ex")
//     public void errorLoggingForOrderControllers(Exception ex) {
//         logger.log(LogLevel.ERROR, ex.getMessage() + "  " + LocalDateTime.now());
//     }

//     // Pointcut for email-related controllers
//     @AfterThrowing(pointcut = "execution(* com.saleex.admin.email.controller.*.*(..))", throwing = "ex")
//     public void errorLoggingForEmailControllers(Exception ex) {
//         logger.log(LogLevel.ERROR, ex.getMessage() + "  " + LocalDateTime.now());
//     }
// }
