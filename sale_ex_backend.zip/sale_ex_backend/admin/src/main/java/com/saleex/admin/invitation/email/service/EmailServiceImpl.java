
package com.saleex.admin.invitation.email.service;

import java.io.IOException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import java.io.ByteArrayOutputStream;
import org.xhtmlrenderer.pdf.ITextRenderer;
import com.lowagie.text.DocumentException;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import com.saleex.admin.invitation.dto.InviteRequestDto;
import com.saleex.admin.invitation.repository.InvitationRepository;
import com.saleex.admin.order.dto.AllOrderDetails;

@Service
@Configuration
public class EmailServiceImpl implements EmailService {
    @Autowired
    private JavaMailSender javaMailSender;
    @Autowired
    private TemplateEngine templateEngine;
    @Autowired
    private InvitationRepository invitationRepository;

    @Override
    public boolean sendInvitationMail(InviteRequestDto user) {
        try {
            System.out.println(user.getInviteeEmail());
            // Fetch the password from the database based on the email
            String password = invitationRepository.findPasswordByInviteeEmail(user.getInviteeEmail())
                    .orElseThrow(() -> new RuntimeException("Password not found for email: " + user.getInviteeEmail()));

            String imageUrl = "https://shehanstechblog.files.wordpress.com/2021/06/2808337.jpg?w=863&h=1&crop=1";
            // Create and send the invitation email using Thymeleaf template
            MimeMessage mimeMessage = javaMailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
            if (user.getInviteeEmail() != null) {
                helper.setTo(user.getInviteeEmail());
            }
            helper.setSubject("Invitation to Your System");
            // Create a Thymeleaf context and set model attributes
            Context thymeleafContext = new Context();
            thymeleafContext.setVariable("user", user);
            thymeleafContext.setVariable("password", password);
            thymeleafContext.setVariable("imageUrl", imageUrl);
            // Process the Thymeleaf template with dynamic values
            String htmlContent = templateEngine.process("invitation-email", thymeleafContext);
            helper.setText(htmlContent, true);
            javaMailSender.send(mimeMessage);
            return true;
        } catch (Exception e) {
            // Handle exceptions appropriately (e.g., log or throw a custom exception)
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public void sendOrderConfirmationEmail(AllOrderDetails orderResponse, String recipientEmail) {
        // Prepare the Thymeleaf context with data
        Context thymeleafContext = new Context();
        // Set variables directly in the Thymeleaf context
        thymeleafContext.setVariable("customerFirstName", orderResponse.getCustomer().getFname());
        thymeleafContext.setVariable("customerLastName", orderResponse.getCustomer().getLname());
        thymeleafContext.setVariable("sellerFullName",
                orderResponse.getSeller().getFname() + ' ' + orderResponse.getSeller().getLname());
        thymeleafContext.setVariable("products", orderResponse.getProduct());
        thymeleafContext.setVariable("totalAmount", orderResponse.getTotal());
        thymeleafContext.setVariable("orderResponse", orderResponse);
        thymeleafContext.setVariable("orderStatus", orderResponse.getOrderStatus());
        // Create the HTML content using Thymeleaf
        String htmlContent = templateEngine.process("order-confirmation", thymeleafContext);
        // Send the email
        sendMailWithHtmlAndAttachment(recipientEmail, "Order Confirmation", htmlContent);
    }

    public void sendMailWithHtmlAndAttachment(String to, String subject, String htmlContent) throws DocumentException {
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        try {
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
            helper.setTo(to);
            helper.setSubject(subject);
            helper.setText(htmlContent, true);
            // Convert HTML to PDF
            byte[] pdfBytes = convertHtmlToPdf(htmlContent);
            ByteArrayResource pdfAttachment = new ByteArrayResource(pdfBytes);
            helper.addAttachment("Invoice.pdf", pdfAttachment);
            javaMailSender.send(mimeMessage);
        } catch (MessagingException e) {
            e.printStackTrace();
            // Handle exception
        }
    }

    private byte[] convertHtmlToPdf(String htmlContent) throws DocumentException {
        try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
            ITextRenderer renderer = new ITextRenderer();
            renderer.setDocumentFromString(htmlContent);
            renderer.layout();
            renderer.createPDF(outputStream, false);
            renderer.finishPDF();
            return outputStream.toByteArray();
        } catch (IOException e) {
            e.printStackTrace();
            // Handle exception
        }
        return null;
    }
}