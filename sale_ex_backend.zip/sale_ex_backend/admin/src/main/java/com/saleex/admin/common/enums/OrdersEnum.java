package com.saleex.admin.common.enums;

public enum OrdersEnum {
    TODO, INPROGRESS, OUT_FOR_DELIVERY, DELIVERED, CANCELLED;

}
