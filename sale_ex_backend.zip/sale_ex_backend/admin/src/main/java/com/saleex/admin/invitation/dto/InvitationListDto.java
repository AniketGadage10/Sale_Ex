package com.saleex.admin.invitation.dto;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class InvitationListDto {

    private String fName;

    private String lName;

    private String inviteeEmail;

    private String inviteeRole;
}
