package com.saleex.admin.invitation.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.saleex.admin.invitation.entity.Invitation;

public interface InvitationRepository extends JpaRepository<Invitation, Long> {

    Optional<Invitation> findByInviteeEmail(String inviteeEmail);

    @Query("SELECT i.password FROM Invitation i WHERE i.inviteeEmail = :inviteeEmail")
    Optional<String> findPasswordByInviteeEmail(@Param("inviteeEmail") String inviteeEmail);

    Optional<Invitation> findByInviteeEmailAndPassword(String email, String password);
}
