package com.saleex.admin.invitation.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.security.authentication.AuthenticationManager;
// import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.saleex.admin.common.enums.EntityStatus;
import com.saleex.admin.common.exception.NotFoundException;
import com.saleex.admin.invitation.dto.InvitationListDto;
import com.saleex.admin.invitation.dto.InviteRequestDto;
import com.saleex.admin.invitation.dto.InviteResponseDto;
import com.saleex.admin.invitation.email.service.EmailService;
import com.saleex.admin.invitation.entity.Invitation;
import com.saleex.admin.invitation.repository.InvitationRepository;
import com.saleex.admin.notification.entity.Notification;
import com.saleex.admin.notification.repository.NotificationRepository;
import com.saleex.admin.user.dto.AuthUserDto;
import com.saleex.admin.user.entity.Role;
import com.saleex.admin.user.entity.User;
import com.saleex.admin.user.entity.UserRole;
import com.saleex.admin.user.repository.RoleRepository;
import com.saleex.admin.user.repository.UserRepository;
import com.saleex.admin.user.repository.UserRoleRepository;

import jakarta.transaction.Transactional;

import java.util.*;

@Service
public class InvitationServiceImpl implements InvitationService {

    @Autowired
    private UserRepository userRepo;

    @Autowired
    private ModelMapper mapper;

    @Autowired
    private RoleRepository roleRepo;

    @Autowired
    private EmailService emailService;

    @Autowired
    private UserRoleRepository userRoleRepo;

    @Autowired
    private NotificationRepository notificationRepo;

    @Autowired
    private InvitationRepository invitationRepo;

    @Transactional
    @Override
    public InviteResponseDto inviteByAdmin(Long id, InviteRequestDto user) {

        List<User> existingUsers = userRepo.findByEmail(user.getInviteeEmail());

        if (!existingUsers.isEmpty()) {
            throw new NotFoundException("User with " + user.getInviteeEmail() + " already exists");
        }

        Role role = roleRepo.findByName(user.getInviteeRole().toUpperCase());
        if (role == null) {
            throw new NotFoundException("Role is valid");
        }

        User admin = userRepo.findById(id)
                .orElseThrow(() -> new NotFoundException("User not found or has been deleted"));

        Invitation invitee = mapper.map(user, Invitation.class);
        invitee.setInviter(admin);
        String password = generateRandomPassword(8);
        invitee.setPassword(password);
        admin.getSentInvitations().add(invitee);

        invitee.setInviteeRole(role.getName());
        invitee.setStatus(EntityStatus.INVITED);

        invitationRepo.save(invitee);

        emailService.sendInvitationMail(user);

        InviteResponseDto response = new InviteResponseDto("Successfully added",
                invitee.getId());

        return response;
    }

    private String generateRandomPassword(int length) {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder password = new StringBuilder();

        for (int i = 0; i < length; i++) {
            int index = (int) (Math.random() * characters.length());
            password.append(characters.charAt(index));
        }

        return password.toString();
    }

    public List<InvitationListDto> getInviteeListById(Long id) {

        User user = userRepo.findById(id)
                .orElseThrow(() -> new NotFoundException("User not found or has been deleted"));

        List<Invitation> inviteeList = user.getSentInvitations();

        List<InvitationListDto> inviteeDtoList = new ArrayList<>();
        for (Invitation invitee : inviteeList) {

            InvitationListDto inv = mapper.map(invitee, InvitationListDto.class);
            inviteeDtoList.add(inv);
        }

        return inviteeDtoList;

    }

    // Firebase notification implementation

    @Transactional
    @Override
    public Long createUserFormInvite(AuthUserDto request) {

        Invitation invitee = invitationRepo.findByInviteeEmailAndPassword(request.getEmail(), request.getPassword())
                .orElseThrow(() -> new NotFoundException("Invitee not found"));

        User user = new User();

        if (invitee == null || invitee.getFName() == null || invitee.getLName() == null
                || invitee.getInviteeEmail() == null || invitee.getPassword() == null) {
            throw new NotFoundException("Invalid credentials");
        }

        user.setFname(invitee.getFName());
        user.setLname(invitee.getLName());
        user.setEmail(invitee.getInviteeEmail());
        user.setPassword(invitee.getPassword());
        user.setStatus(EntityStatus.INVITED);
        user.setContact("N/A");
        user.setAddress(null);
        Set<UserRole> set = new HashSet<>();
        UserRole userRole = new UserRole(user, roleRepo.findByName(invitee.getInviteeRole()));
        set.add(userRole);
        userRoleRepo.save(userRole);
        user.setUserRoles(set);

        if (user.getNotifications() == null) {
            user.setNotifications(new ArrayList<>());
        }

        User savedUser = userRepo.save(user);

        Notification notifyUser;

        if (savedUser.getNotifications().isEmpty()) {
            notifyUser = new Notification();
            notifyUser.setFirebaseToken(request.getFirebaseToken());
            notifyUser.setUser(savedUser);
        } else {
            notifyUser = savedUser.getNotifications().get(0);
            notifyUser.setFirebaseToken(request.getFirebaseToken());
            notifyUser.setUser(savedUser);
        }

        notificationRepo.save(notifyUser);

        savedUser.getNotifications().add(notifyUser);

        userRepo.save(savedUser);

        invitationRepo.delete(invitee);

        return savedUser.getId();
    }

    @Transactional
    @Override
    public String confirmInvitee(AuthUserDto user) {

        // Invitation invitee =
        // invitationRepo.findByInviteeEmailAndPassword(user.getEmail(),
        // user.getPassword())
        // .orElseThrow(() -> new NotFoundException("Invitee Not found"));

        return "Successfully login as a invitee";
    }

}
