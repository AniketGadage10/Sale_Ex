package com.saleex.admin.user.repository;

import java.util.List;
import java.util.Date;

import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.domain.Pageable;

import com.saleex.admin.common.enums.EntityStatus;
import com.saleex.admin.user.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {

        List<User> findByEmailAndPassword(String email, String password);

        List<User> findByEmail(String email);

        @Query("SELECT u FROM User u WHERE u.joiningDate BETWEEN :startDate AND :endDate")
        Page<User> findByJoiningDates(@Param("startDate") Date startDate, @Param("endDate") Date endDate,
                        Pageable pageable);

        @Query("SELECT u FROM User u " +
                        "JOIN UserRole ur ON u.id = ur.user.id " +
                        "JOIN Role r ON ur.role.id = r.id " +
                        "WHERE r.name = :roleName")
        Page<User> findByRoleName(@Param("roleName") String roleName, Pageable pageable);

        Page<User> findByStatus(@Param("status") EntityStatus status, Pageable pageable);

        @Query("SELECT u FROM User u WHERE LOWER(u.fname) LIKE LOWER(CONCAT('%', :name, '%')) OR LOWER(u.lname) LIKE LOWER(CONCAT('%', :name, '%'))")
        Page<User> findByUsernameWithPagination(@Param("name") String name, Pageable pageable);

        @Query("SELECT DISTINCT u FROM User u JOIN u.userRoles r WHERE r.role.name ='CUSTOMER' AND (LOWER(u.fname) LIKE LOWER(CONCAT('%', :name, '%')) OR LOWER(u.lname) LIKE LOWER(CONCAT('%', :name, '%')))")
        Page<User> findCustomersByName(@Param("name") String name, Pageable pageable);

}