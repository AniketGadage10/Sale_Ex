package com.saleex.admin.notification.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.saleex.admin.notification.entity.Notification;
import com.saleex.admin.user.entity.User;

import java.util.*;

public interface NotificationRepository extends JpaRepository<Notification, Long> {

    List<Notification> findByUser(User user);

    List<String> findFirebaseTokensByUserId(Long userId);

    List<Notification> findNotificationsByUserId(Long userId);

}
