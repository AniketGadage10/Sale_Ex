package com.saleex.admin.notification.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.saleex.admin.notification.entity.Messages;

import java.util.*;

public interface MessageRepository extends JpaRepository<Messages, Long> {

    List<Messages> findByUserId(Long userId);

}
