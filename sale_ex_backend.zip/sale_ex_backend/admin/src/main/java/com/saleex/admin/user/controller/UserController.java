package com.saleex.admin.user.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.saleex.admin.auth.jwt.token.RequestToken;
import com.saleex.admin.auth.jwt.token.TokenDto;
import com.saleex.admin.common.model.ResponseEntity;
import com.saleex.admin.user.dto.AdminDto;
import com.saleex.admin.user.dto.AuthUserDto;
import com.saleex.admin.user.dto.CustomerResponseDto;
import com.saleex.admin.user.dto.StatusDto;
import com.saleex.admin.user.dto.UserFullDetails;
import com.saleex.admin.user.dto.UserRequestDto;
import com.saleex.admin.user.dto.UserResponseDto;
import com.saleex.admin.user.service.UserService;

import io.jsonwebtoken.io.IOException;
import jakarta.validation.Valid;

import static com.saleex.admin.common.constants.Constants.*;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
@CrossOrigin("*")
@RequestMapping(USER_URI)
public class UserController {
    @Autowired
    private UserService userService;

    // @PreAuthorize("hasAuthority('ADMIN')")
    // @PreAuthorize("isAuthenticated()")

    @PostMapping("/create")
    public ResponseEntity<UserResponseDto> createUser(@RequestBody @Valid AdminDto userResponse)
            throws IOException, java.io.IOException {
        UserResponseDto createdUser = userService.createUser(userResponse);
        return (createdUser != null) ? ResponseEntity.success(
                createdUser) : ResponseEntity.error("User page not found");

    }

    // @PreAuthorize("isAuthenticated()")
    @GetMapping(ID)
    public ResponseEntity<UserFullDetails> getUserById(@PathVariable Long id) {
        UserFullDetails user = userService.getUserById(id);
        return (user != null) ? ResponseEntity.success(user) : ResponseEntity.error("User not found");

    }

    @PostMapping("/login")
    public ResponseEntity<TokenDto> userLogin(@RequestBody AuthUserDto authUser) {

        System.out.println(authUser.getEmail() + " " + authUser.getPassword()
                + " " + authUser.getFirebaseToken());
        TokenDto token = userService.userLogin(authUser);
        return (token != null) ? ResponseEntity.success(token) : ResponseEntity.error("Token not found");

    }

    @PutMapping(ID)
    // @PreAuthorize("isAuthenticated()")
    public ResponseEntity<UserResponseDto> updateUser(@RequestBody @Valid UserRequestDto userRequest,
            @PathVariable Long id) throws java.io.IOException {
        UserResponseDto user = userService.updateUser(id, userRequest);
        return (user != null) ? ResponseEntity.success(user) : ResponseEntity.error("User not found");
    }

    @DeleteMapping(ID)
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<UserResponseDto> deleteUser(@PathVariable Long id) {
        UserResponseDto user = userService.deleteUser(id);
        return (user != null) ? ResponseEntity.success(user) : ResponseEntity.error("User not found");
    }

    @PostMapping("/reGenerateToken")
    // @PreAuthorize("isAuthenticated()")
    public ResponseEntity<String> generateTokenFromRefreshToken(@RequestBody RequestToken refreshToken) {
        String token = userService.generateTokenFromRefreshToken(refreshToken);
        return (token != null) ? ResponseEntity.success(token) : ResponseEntity.error("token not found");

    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping
    public ResponseEntity<List<UserResponseDto>> getUserList() {
        List<UserResponseDto> userList = userService.listOfUsers();
        return (userList != null) ? ResponseEntity.success(userList) : ResponseEntity.error("User List is empty");

    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/date/{startDate}&{endDate}")
    public ResponseEntity<Page<UserResponseDto>> sortingByDate(
            @PathVariable String startDate,
            @PathVariable String endDate,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        LocalDate parsedStartDate = LocalDate.parse(startDate);
        Date javaUtilStartDate = Date.from(parsedStartDate.atStartOfDay(ZoneId.systemDefault()).toInstant());

        LocalDate parsedEndDate = LocalDate.parse(endDate);
        Date javaUtilEndDate = Date.from(parsedEndDate.atStartOfDay(ZoneId.systemDefault()).toInstant());

        Page<UserResponseDto> userPage = userService.filterByDate(javaUtilStartDate, javaUtilEndDate, page, size);

        return (userPage != null) ? ResponseEntity.success(userPage) : ResponseEntity.error("User page not found");

    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/role/{role}")
    public ResponseEntity<Page<UserResponseDto>> sortedByRole(
            @PathVariable String role,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        Page<UserResponseDto> userPage = userService.filterByRoles(role, page, size);

        return (userPage != null) ? ResponseEntity.success(userPage) : ResponseEntity.error("User page not found");

    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping(CUSTOMER_URI)
    public ResponseEntity<Page<CustomerResponseDto>> customerList(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        Page<CustomerResponseDto> userPage = userService.customerList(page, size);

        return (userPage != null) ? ResponseEntity.success(
                userPage) : ResponseEntity.error("User page not found");

    }

    @GetMapping(CUSTOMER_URI + "/{name}")
    public ResponseEntity<Page<UserResponseDto>> filterCustomer(
            @PathVariable String name,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {

        Page<UserResponseDto> userPage = userService.filterByRoles(name, page, size);

        return (userPage != null) ? ResponseEntity.success(userPage) : ResponseEntity.error("User page not found");

    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/page")
    public ResponseEntity<Page<UserResponseDto>> userByPagination(
            @RequestParam(value = "pageNumber", defaultValue = "0", required = false) Integer pageNumber,
            @RequestParam(value = "pageSize", defaultValue = "14", required = false) Integer pageSize) {
        Page<UserResponseDto> userPage = userService.listOfUsersByPagination(pageNumber, pageSize);
        return (userPage != null) ? ResponseEntity.success(userPage) : ResponseEntity.error("User page not found");
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/status/{status}")
    public ResponseEntity<Page<UserResponseDto>> userByStatus(
            @RequestParam(value = "pageNumber", defaultValue = "0", required = false) Integer pageNumber,
            @RequestParam(value = "pageSize", defaultValue = "10", required = false) Integer pageSize,
            @PathVariable String status) {
        Page<UserResponseDto> userPage = userService.listOfUserByStatus(pageNumber, pageSize, status);
        return (userPage != null) ? ResponseEntity.success(userPage) : ResponseEntity.error("User page not found");
    }

    // @PreAuthorize("isAuthenticated()")
    @PostMapping("/status/{status}/{id}")
    public ResponseEntity<StatusDto> changeStatus(@PathVariable String status, @PathVariable Long id) {

        StatusDto response = userService.changeStatus(status, id);
        return (response != null) ? ResponseEntity.success(response) : ResponseEntity.error("User page not found");

    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/name/{username}")
    public ResponseEntity<Page<UserResponseDto>> findByNameWithPagination(@PathVariable String username,
            @RequestParam(value = "pageNumber", defaultValue = "0", required = false) Integer pageNumber,
            @RequestParam(value = "pageSize", defaultValue = "10", required = false) Integer pageSize) {
        Page<UserResponseDto> response = userService.findEntitiesByNameWithPagination(username, pageNumber, pageSize);

        return (response != null) ? ResponseEntity.success(response) : ResponseEntity.error("User page not found");

    }

}