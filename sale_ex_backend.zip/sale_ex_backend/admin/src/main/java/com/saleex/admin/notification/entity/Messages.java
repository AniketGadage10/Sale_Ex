package com.saleex.admin.notification.entity;

import java.util.Date;

import org.hibernate.annotations.UpdateTimestamp;

import com.saleex.admin.common.enums.OrdersEnum;
import com.saleex.admin.entity.BaseEntity;
import com.saleex.admin.user.entity.User;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "message")
@Entity
public class Messages extends BaseEntity {

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "send_time")
    private Date time;

    @Column(name = "order_status")
    private OrdersEnum order_state;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

}
