package com.saleex.admin.order.orderService;

import java.util.Map.Entry;
import java.util.stream.Collectors;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.nio.charset.StandardCharsets;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import com.saleex.admin.common.enums.EntityStatus;
import com.saleex.admin.common.enums.OrdersEnum;
import com.saleex.admin.common.exception.NotFoundException;
import com.saleex.admin.invitation.email.service.EmailService;
import com.saleex.admin.notification.entity.Messages;
import com.saleex.admin.notification.entity.Notification;
import com.saleex.admin.notification.repository.MessageRepository;
import com.saleex.admin.notification.repository.NotificationRepository;
import com.saleex.admin.order.dto.ActiveOrderDetails;
import com.saleex.admin.order.dto.AllOrderDetails;
import com.saleex.admin.order.dto.ChangeStatusDto;
import com.saleex.admin.order.dto.OrderRequestDto;
import com.saleex.admin.order.dto.OrderResponseDto;
import com.saleex.admin.order.dto.OrderedProductList;
import com.saleex.admin.order.entity.Order;
import com.saleex.admin.order.entity.OrderProducts;
import com.saleex.admin.order.orderProduct.repository.ProductOrderRepository;
import com.saleex.admin.order.repository.OrderRepository;
import com.saleex.admin.product.dto.AddProductResponseDto;
import com.saleex.admin.product.dto.ProductDto;
import com.saleex.admin.product.dto.ProductResponseDto;
import com.saleex.admin.product.entity.Product;
import com.saleex.admin.product.repository.ProductRepository;
import com.saleex.admin.user.dto.UserResponseDto;
import com.saleex.admin.user.entity.User;
import com.saleex.admin.user.repository.UserRepository;

import jakarta.transaction.Transactional;

import com.google.firebase.messaging.*;

@Service

public class OrderServiceImpl implements OrderService {
    @Autowired
    private UserRepository userRepo;

    @Autowired
    private OrderRepository orderRepo;

    @Autowired
    private ProductRepository productRepo;

    @Autowired
    private ModelMapper mapper;

    @Autowired
    private MessageRepository messageRepo;

    @Autowired
    private NotificationRepository notificationRepo;

    @Autowired
    private ProductOrderRepository orderProductRepo;

    @Autowired
    private EmailService emailService;

    @Transactional
    @Override
    public AllOrderDetails createOrder(Long seller_id, OrderRequestDto orderDetails) {
        User seller = userRepo.findById(seller_id)
                .orElseThrow(() -> new NotFoundException("Seller not found  or has been deleted"));
        checkUserActivity(seller);
        User customer = userRepo.findById(orderDetails.getCustomerId())
                .orElseThrow(() -> new NotFoundException("Customer not found  or has been deleted"));
        checkUserActivity(customer);
        if (customer.getUserRoles()
                .stream()
                .noneMatch(userRole -> userRole.getRole().getName().equals("CUSTOMER"))) {
            throw new NotFoundException("User is not a customer");
        }
        // BigDecimal totalAmount = orderDetails.getTotalAmount().setScale(3,
        // RoundingMode.DOWN);
        OrdersEnum orderStatus = safelyGetOrderStatus(orderDetails.getStatus().toUpperCase());
        Order order = new Order();
        // order.setTotalAmount(totalAmount.setScale(3, RoundingMode.DOWN));
        order.setSellers(Collections.singletonList(seller));
        order.setOrderStatus(orderStatus);
        order.setCustomer(customer);

        double totalAmount = 0;
        List<OrderProducts> orderProductList = new ArrayList<>();
        for (Entry<Long, Integer> entry : orderDetails.getProduct_quantity().entrySet()) {
            Product product = productRepo.findById(entry.getKey())
                    .orElseThrow(() -> new NotFoundException("Product unavailable"));
            Integer quantity = entry.getValue();
            if (quantity > product.getQuantity()) {
                throw new NotFoundException("Product quantity is out of range");
            }
            OrderProducts orderedProduct = new OrderProducts();
            orderedProduct.setOrder(order);
            orderedProduct.setProduct(product);
            orderedProduct.setSeller(seller);
            orderedProduct.setQuantity(quantity);
            totalAmount += (double) product.getPrice().doubleValue();
            product.setQuantity(product.getQuantity() - quantity);
            productRepo.save(product);
            OrderProducts savedProductOrder = orderProductRepo.save(orderedProduct);
            orderProductList.add(savedProductOrder);
        }
        order.setTotalAmount(BigDecimal.valueOf(totalAmount).setScale(3,
                RoundingMode.DOWN));
        order.setOrderProducts(orderProductList);
        order.setStatus(EntityStatus.ACTIVE);
        Order savedOrder = orderRepo.save(order);
        customer.getOrders().add(savedOrder);
        Messages msg = createMessage(savedOrder.getId(), savedOrder.getOrderStatus(), seller);
        msg.setStatus(EntityStatus.ACTIVE);
        customer.getMessages().add(messageRepo.save(msg));
        userRepo.save(customer);
        // notification code...
        // System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
        // + orderDetails.getCustomerId());
        // System.out.println("----------------" + seller_id);
        // List<Notification> notifications = notificationRepo
        // .findNotificationsByUserId(seller_id);
        // // List<String> firebaseTokens = notifications.stream()
        // // .map(Notification::getFirebaseToken)
        // // .collect(Collectors.toList());
        // System.out.println("++++++++++++++++++++++++++++" +
        // notifications.get(0).getFirebaseToken());
        // // // for (String firebaseToken : firebaseTokens) {
        // sendFirebasePushNotification(
        // notifications.get(0).getFirebaseToken(), savedOrder.getOrderStatus().name());
        // // }
        // *******************************************************************************************************
        // */}
        AllOrderDetails orderResponses = convertOrderToAllOrderDetails(savedOrder);
        emailService.sendOrderConfirmationEmail(orderResponses, customer.getEmail());
        return orderResponses;
    }

    private AllOrderDetails convertOrderToAllOrderDetails(Order order) {
        List<ProductResponseDto> productDtoList = new ArrayList<>();

        for (OrderProducts orderedProduct : order.getOrderProducts()) {
            Product product = orderedProduct.getProduct();

            List<String> listOfPicture = new ArrayList<>();

            for (byte[] picture : orderedProduct.getProduct().getPicture()) {
                listOfPicture.add(new String(picture, StandardCharsets.UTF_8));

            }

            ProductResponseDto productDto = new ProductResponseDto(
                    product.getId(),
                    product.getProductName(),
                    product.getDescription(),
                    orderedProduct.getQuantity(),
                    product.getPrice().setScale(3,
                            RoundingMode.DOWN),
                    listOfPicture,
                    product.getProductType());

            productDtoList.add(productDto);
        }

        UserResponseDto sellerDto = mapper.map(order.getSellers().get(0), UserResponseDto.class);

        order.getSellers().get(0).getUserRoles().stream().forEach((e) -> sellerDto.setRole(e.getRole().getName()));

        UserResponseDto customerDto = mapper.map(order.getCustomer(), UserResponseDto.class);

        order.getCustomer().getUserRoles().stream().forEach((e) -> customerDto.setRole(e.getRole().getName()));

        return new AllOrderDetails(sellerDto, customerDto, productDtoList, order.getTotalAmount().setScale(3,
                RoundingMode.DOWN), order.getOrderStatus().name(), order.getDateOfOrder());
    }

    private OrdersEnum safelyGetOrderStatus(String status) {
        try {
            return OrdersEnum.valueOf(status);
        } catch (IllegalArgumentException e) {
            throw new NotFoundException("Status Not Found");
        }
    }

    private void checkUserActivity(User user) {
        if ((user.getStatus() == EntityStatus.DEACTIVATE)) {
            throw new NotFoundException("User not found  or has been deleted");
        }
    }

    private void checkProductDeleted(Product product) {
        if (product.getStatus() == EntityStatus.DEACTIVATE) {
            throw new NotFoundException("User not found  or has been deleted");
        }
    }

    @Transactional
    @Override
    public AllOrderDetails updateOrder(Long orderId, Long sellerId, OrderRequestDto orderDetails) {
        Order order = orderRepo.findById(orderId).orElseThrow(() -> new NotFoundException("Order not found "));
        User seller = userRepo.findById(sellerId)
                .orElseThrow(() -> new NotFoundException("Seller not found  or has been deleted"));
        checkUserActivity(seller);
        if (order.getStatus() == EntityStatus.DEACTIVATE) {
            throw new NotFoundException("User not found  or has been deleted");
        }
        order.setTotalAmount(orderDetails.getTotalAmount().setScale(3, RoundingMode.DOWN));
        OrdersEnum orderStatus = safelyGetOrderStatus(orderDetails.getStatus());
        order.setOrderStatus(orderStatus);
        order.setStatus(EntityStatus.ACTIVE);
        order.setDateOfOrder(new Date());
        List<OrderProducts> orderProductList = new ArrayList<>();
        double totalAmount = 0;
        Set<Long> updatedProductIds = new HashSet<>();
        for (Entry<Long, Integer> entry : orderDetails.getProduct_quantity().entrySet()) {
            Product product = productRepo.findById(entry.getKey())
                    .orElseThrow(() -> new NotFoundException("Product unavailable"));
            Integer quantity = entry.getValue();
            if (quantity > product.getQuantity()) {
                throw new NotFoundException("Product quantity is out of range");
            }
            checkProductDeleted(product);
            OrderProducts orderedProduct = orderProductRepo.findByOrderAndProduct(order, product)
                    .orElseThrow(() -> new NotFoundException("Ordered product unavailable"));
            int oldQuantity = orderedProduct.getQuantity();
            if (quantity != oldQuantity) {
                // int difference = quantity - oldQuantity;
                product.setQuantity(product.getQuantity() + oldQuantity);
                product.setQuantity(product.getQuantity() - quantity);
            }
            totalAmount += product.getPrice().doubleValue();
            orderedProduct.setQuantity(quantity);
            OrderProducts savedProductOrder = orderProductRepo.save(orderedProduct);
            orderProductList.add(savedProductOrder);
            if (quantity == 0) {
                orderProductRepo.delete(orderedProduct);
            }
            updatedProductIds.add(product.getId());
        }
        for (OrderProducts existingProduct : order.getOrderProducts()) {
            if (!updatedProductIds.contains(existingProduct.getProduct().getId())) {
                Product remainingProduct = existingProduct.getProduct();
                remainingProduct.setQuantity(remainingProduct.getQuantity() + existingProduct.getQuantity());
                productRepo.save(remainingProduct);
                orderProductRepo.delete(existingProduct);
            }
        }
        order.setTotalAmount(BigDecimal.valueOf(totalAmount).setScale(3,
                RoundingMode.DOWN));
        order.setOrderProducts(orderProductList);
        Order updatedOrder = orderRepo.save(order);
        User customer = userRepo.findById(orderDetails.getCustomerId())
                .orElseThrow(() -> new NotFoundException("Customer not found  or has been deleted"));
        Messages msg = createMessage(updatedOrder.getId(), updatedOrder.getOrderStatus(), seller);
        msg.setStatus(EntityStatus.ACTIVE);
        customer.getMessages().add(messageRepo.save(msg));
        userRepo.save(customer);
        // notification code...
        System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
                + orderDetails.getCustomerId());
        List<Notification> notifications = notificationRepo
                .findNotificationsByUserId(sellerId);
        System.out.println("+++++++++++++" + sellerId + "+++++++++++++++" + notifications.get(0).getFirebaseToken());
        String notificationMessage = "Your order " + updatedOrder.getId() + " status changed to "
                + updatedOrder.getOrderStatus().name();
        sendFirebasePushNotification(
                "fEOlr48mRIWOa5oEGXP0e3:APA91bFRpunXPMjUZtDIlHcCCz_JiNbha7yGU7al7OCS3VFCZY1Ac9JYib1Q2qQXic-FVcNjToF79XVlgOhq89rxcSJVP4KyTNVmq92ZN90p4AetTkBZfiuYhB3Fue3G-jDmwDembogs",
                notificationMessage);
        // sendFirebasePushNotification(notifications.get(0).getFirebaseToken(),
        // updatedOrder.getOrderStatus().name());
        AllOrderDetails orderResponses = convertOrderToAllOrderDetails(updatedOrder);
        emailService.sendOrderConfirmationEmail(orderResponses, customer.getEmail());
        return orderResponses;
    }

    private Messages createMessage(Long orderId, OrdersEnum status, User user) {
        Messages message = new Messages();
        message.setOrder_state(status);
        message.setUser(user);
        message.setStatus(EntityStatus.ACTIVE);
        return message;
    }

    @Transactional
    @Override
    public OrderResponseDto deleteOrder(Long id) {
        Order order = orderRepo.findById(id).orElseThrow(() -> new NotFoundException("Order not found "));

        if (order.getStatus() == EntityStatus.DEACTIVATE) {
            throw new NotFoundException("Order not found  or has been deleted");
        }

        order.setOrderStatus(OrdersEnum.CANCELLED);

        for (OrderProducts orderProduct : order.getOrderProducts()) {
            Product product = productRepo.findById(orderProduct.getProduct().getId())
                    .orElseThrow(() -> new NotFoundException("Product unavailable"));

            int orderProductQuantity = orderProduct.getQuantity();
            product.setQuantity(product.getQuantity() + orderProductQuantity);
            productRepo.save(product);
            orderProductRepo.delete(orderProduct);
        }

        orderRepo.save(order);

        return new OrderResponseDto(order.getId(), order.getStatus().name(),
                order.getCustomer().getId(),
                order.getSellers().get(0).getId());
    }

    @Override
    public OrderedProductList getOrderbyId(Long id) {
        Order order = orderRepo.findById(id).orElseThrow(() -> new NotFoundException("Order not found "));

        OrderedProductList orderList = new OrderedProductList();

        if (order.getStatus() == EntityStatus.DEACTIVATE) {
            throw new NotFoundException("Order not found  or has been deleted");
        }

        orderList.setOrderedProduct(productList(order.getOrderProducts()));
        orderList.setCustomer(userToDto(order.getCustomer()));
        orderList.setSeller(userToDto(order.getSellers().get(0)));
        orderList.setStatus(order.getOrderStatus().name());
        orderList.setId(order.getId());
        orderList.setOrderDate(order.getDateOfOrder());
        orderList.setTotal_amount(order.getTotalAmount().setScale(3, RoundingMode.DOWN));

        return orderList;

    }

    @Override
    public AllOrderDetails changeOrderStatus(ChangeStatusDto statusDetails) {
        Order order = orderRepo.findById(statusDetails.getId())
                .orElseThrow(() -> new NotFoundException("Order not found"));
        Long orderId = statusDetails.getId();

        Long sellerId = order.getSellers().get(0).getId();

        OrderRequestDto orderDetails = new OrderRequestDto();

        orderDetails.setCustomerId(order.getCustomer().getId());

        orderDetails.setStatus(statusDetails.getStatus());

        Map<Long, Integer> list = new HashMap<>();
        for (OrderProducts orderProducts : order.getOrderProducts()) {
            list.put(orderProducts.getProduct().getId(), orderProducts.getQuantity());
        }
        orderDetails.setProduct_quantity(list);
        orderDetails.setTotalAmount(order.getTotalAmount());

        return updateOrder(orderId, sellerId, orderDetails);
    }

    @Override
    @Transactional
    public List<OrderedProductList> orderedProductList() {
        List<Order> totalOrders = orderRepo.findAll();

        if (totalOrders.isEmpty()) {
            throw new NotFoundException("No orders found");
        }
        List<OrderedProductList> orderedProductList = new ArrayList<>();

        for (Order order : totalOrders) {
            OrderedProductList orderList = new OrderedProductList();
            if (order.getStatus() == EntityStatus.DEACTIVATE) {
                continue;
            }
            orderList.setOrderedProduct(productList(order.getOrderProducts()));
            orderList.setCustomer(userToDto(order.getCustomer()));
            orderList.setSeller(userToDto(order.getSellers().get(0)));
            orderList.setStatus(order.getOrderStatus().name());
            orderList.setId(order.getId());
            orderList.setOrderDate(order.getDateOfOrder());
            orderList.setTotal_amount(order.getTotalAmount().setScale(3, RoundingMode.DOWN));
            orderedProductList.add(orderList);
        }
        System.out.println("------------" + 1);
        return orderedProductList;
    }

    private UserResponseDto userToDto(User user) {
        UserResponseDto userResponse = mapper.map(user, UserResponseDto.class);
        user.getUserRoles().forEach(e -> userResponse.setRole(e.getRole().getName()));

        // Add null check for user profile
        if (user.getUserProfile() != null) {
            userResponse.setUserProfile(new String(user.getUserProfile(), StandardCharsets.UTF_8));
        } else {
            // Handle the case where user profile is null
            userResponse.setUserProfile("Image not available");
        }

        userResponse.setStatus(user.getStatus().name());
        return userResponse;
    }

    private List<AddProductResponseDto> productList(List<OrderProducts> orderProducts) {
        List<AddProductResponseDto> list = new ArrayList<>();

        for (OrderProducts orderProduct : orderProducts) {
            Product product = orderProduct.getProduct();
            checkProductDeleted(product);

            AddProductResponseDto productDto;
            try {
                productDto = mapper.map(product, AddProductResponseDto.class);
                List<String> productPicture = new ArrayList<>();
                for (byte[] picture : product.getPicture()) {
                    productPicture.add(new String(picture, StandardCharsets.UTF_8));
                }
                productDto.setPicture(productPicture);

                list.add(productDto);
            } catch (Exception e) {
                throw new NotFoundException("List is epmty");
            }
        }
        return list;
    }

    // firebase implementation

    private void sendFirebasePushNotification(String firebaseToken, String newOrderStatus) {
        // Implement the logic to send push notification using Firebase Admin SDK or FCM
        // API
        // Example using Firebase Admin SDK (you need to set up Firebase Admin SDK in
        // your project)
        System.out.println("----------------------" + firebaseToken + "0----------------------");
        Message message = Message.builder()
                .setToken(firebaseToken)
                .putData("orderStatus", newOrderStatus)
                .build();
        try {
            String response = FirebaseMessaging.getInstance().send(message);
            System.out.println("Successfully sent message: " + response);
        } catch (FirebaseMessagingException e) {
            System.err.println("Error sending message: " + e.getMessage());
        }
    }

    @Override
    public Page<AllOrderDetails> filterProductsById(Long id, int pageNumber, int pageSize) {

        Pageable pageable = PageRequest.of(pageNumber, pageSize);
        Page<Order> orderPage = orderRepo.findByIdWithPaginationPage(id + "", pageable);
        List<AllOrderDetails> responseList = new ArrayList<>();
        for (Order order : orderPage) {
            responseList.add(convertOrderToAllOrderDetails(order));
        }

        return new PageImpl<>(responseList, pageable, orderPage.getTotalElements());
    }

    @Transactional
    @Override
    public Page<OrderedProductList> ordersByStatus(String status, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Order> ordersByStatusPage = orderRepo.findByStatus(OrdersEnum.valueOf(status), pageable);

        if (ordersByStatusPage.isEmpty()) {
            throw new NotFoundException("No orders found with status: " + status);
        }

        List<OrderedProductList> orderedProductList = ordersByStatusPage.getContent().stream()
                .map(order -> {
                    OrderedProductList orderList = new OrderedProductList();

                    if (order.getStatus() == EntityStatus.DEACTIVATE) {
                        return null;
                    }

                    orderList.setOrderedProduct(productList(order.getOrderProducts()));
                    orderList.setStatus(order.getStatus().name());
                    orderList.setTotal_amount(order.getTotalAmount().setScale(3, RoundingMode.DOWN));

                    return orderList;
                })
                .filter(Objects::nonNull)
                .collect(Collectors.toList());

        return new PageImpl<>(orderedProductList, pageable, ordersByStatusPage.getTotalElements());
    }

    @Override
    @Transactional
    public ActiveOrderDetails orderDetails() {
        int cancelledOrders = orderRepo.findByOrderStatus(OrdersEnum.CANCELLED).size();
        int completedOrders = orderRepo.findByOrderStatus(OrdersEnum.OUT_FOR_DELIVERY).size();
        int outgoingOrders = orderRepo.findByOrderStatus(OrdersEnum.INPROGRESS).size();
        int totalOrders = orderRepo.findAll().size();
        double cancelledPercentage = calculatePercentage(cancelledOrders, totalOrders);
        double completedPercentage = calculatePercentage(completedOrders, totalOrders);
        double outgoingPercentage = calculatePercentage(outgoingOrders, totalOrders);

        double totalOrderPercentage = ((cancelledOrders + completedOrders + outgoingOrders) / (double) totalOrders)
                * 100.0;
        totalOrderPercentage = Double.parseDouble(String.format("%.2f", totalOrderPercentage));
        List<ProductDto> topSellingProducts = productToDto(productRepo.findTop5ByOrderBySoldQuantityDesc());
        List<ProductDto> last7Days = productToDto(productRepo.findTop5ByQuantityComparisonForLast7Days());
        Map<String, ProductResponseDto> todaysOrder = todaysOrder();
        BigDecimal totalPrice = todaysOrder.values().stream()
                .map(ProductResponseDto::getPrice)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        return new ActiveOrderDetails(
                cancelledOrders, completedOrders, outgoingOrders, totalOrders,
                cancelledPercentage, completedPercentage,
                outgoingPercentage, totalOrderPercentage, totalPrice.doubleValue(),
                topSellingProducts, todaysOrder, last7Days);
    }

    private List<ProductDto> productToDto(List<Product> productList) {
        List<ProductDto> topSellingProducts = new ArrayList<>();

        for (Product product : productList) {
            ProductDto productDto = mapper.map(product, ProductDto.class);
            productDto.setQuantity(product.getFixedQuantity() - product.getQuantity());
            productDto.setPrice(BigDecimal.valueOf((product.getFixedQuantity() - product.getQuantity())
                    * productDto.getPrice().doubleValue()).setScale(2, RoundingMode.DOWN));
            topSellingProducts.add(productDto);

        }
        return topSellingProducts;
    }

    private Map<String, ProductResponseDto> todaysOrder() {
        List<Order> todaysOrders = orderRepo.findTodaysOrders();

        List<AllOrderDetails> list = new ArrayList<>();
        for (Order order : todaysOrders) {
            list.add(convertOrderToAllOrderDetails(order));
        }

        Map<String, ProductResponseDto> todayList = new HashMap<>();

        for (AllOrderDetails orderProductList : list) {
            for (ProductResponseDto product : orderProductList.getProduct()) {
                String productName = product.getProductName();
                int quantity = product.getQuantity();
                BigDecimal price = product.getPrice().setScale(3, RoundingMode.DOWN);

                if (todayList.containsKey(productName)) {
                    // Create a new product with the same details
                    ProductResponseDto existingProduct = todayList.get(productName);
                    ProductResponseDto newProduct = new ProductResponseDto();
                    newProduct.setProductName(existingProduct.getProductName());
                    newProduct.setQuantity(existingProduct.getQuantity() + quantity);
                    newProduct.setPrice(
                            existingProduct.getPrice().add(BigDecimal.valueOf(quantity * price.doubleValue()))
                                    .setScale(2, RoundingMode.DOWN));

                    // Update the map with the new product
                    todayList.put(productName, newProduct);
                } else {
                    // New product, add it to the map
                    todayList.put(productName, product);
                }
            }
        }

        return todayList;
    }

    public int getLastMonthOrders(OrdersEnum status) {

        Date currentDate = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(currentDate);

        calendar.add(Calendar.MONTH, -1);
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        Date lastMonthStartDate = calendar.getTime();

        calendar.setTime(currentDate);

        calendar.set(Calendar.DAY_OF_MONTH, 1);
        calendar.add(Calendar.DATE, -1);
        Date lastMonthEndDate = calendar.getTime();

        List<Order> orders = orderRepo.findByOrderStatusAndDateOfOrderBetween(
                status, lastMonthStartDate, lastMonthEndDate);

        return orders.size();
    }

    public double compareLastMonthTotalToNow() {

        Date currentDate = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(currentDate);
        calendar.add(Calendar.MONTH, -1);
        calendar.set(Calendar.DAY_OF_MONTH, 1);

        Date lastMonthStartDate = calendar.getTime();
        calendar.setTime(currentDate);
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        calendar.add(Calendar.DATE, -1);
        Date lastMonthEndDate = calendar.getTime();

        List<Order> lastMonthOrders = orderRepo.findByDateOfOrderBetween(lastMonthStartDate, lastMonthEndDate);
        int lastMonthTotalOrders = lastMonthOrders.size();

        List<Order> currentMonthOrders = orderRepo.findByDateOfOrderBetween(
                getStartOfMonth(currentDate), getEndOfMonth(currentDate));
        int currentMonthTotalOrders = currentMonthOrders.size();

        return calculatePercentage(currentMonthTotalOrders, lastMonthTotalOrders);
    }

    private Date getStartOfMonth(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        return calendar.getTime();
    }

    private Date getEndOfMonth(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        return calendar.getTime();
    }

    private double calculatePercentage(int newOrders, int oldOrders) {
        if (oldOrders == 0) {
            return 0.0;
        }
        double percentage = ((double) newOrders / oldOrders) * 100.0;
        return Double.parseDouble(String.format("%.2f", percentage));
    }
}
