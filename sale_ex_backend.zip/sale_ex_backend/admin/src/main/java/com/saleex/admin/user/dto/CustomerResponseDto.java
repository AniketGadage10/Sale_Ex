package com.saleex.admin.user.dto;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Setter
public class CustomerResponseDto {

    private Long id;

    private String fname;

    private String lname;

    private String email;

    private String contact;

    private String address;

    private String userProfile;

    private String role;

    private Date joiningDate;

    private String status;

    private UserResponseDto seller;

}