package com.saleex.admin.product.dto;

import java.util.*;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class ProductDtoForMobile {
    Map<Long, String> productDetails = new HashMap<>();

}
