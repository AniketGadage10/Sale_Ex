package com.saleex.admin.invitation.entity;

import lombok.*;

import com.saleex.admin.entity.BaseEntity;
import com.saleex.admin.user.entity.User;

import jakarta.persistence.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "invitations")

public class Invitation extends BaseEntity {

    @ManyToOne
    @JoinColumn(name = "inviter_user_id")
    private User inviter;

    @Column(name = "f_name")
    private String fName;

    @Column(name = "l_name")
    private String lName;

    @Column(name = "invitee_email", unique = true)
    private String inviteeEmail;

    @Column(name = "password")
    private String password;

    @Column(name = "invitee_role")
    private String inviteeRole;

}
