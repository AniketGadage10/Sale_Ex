package com.saleex.admin.invitation.service;

import com.saleex.admin.invitation.dto.InviteRequestDto;
import com.saleex.admin.invitation.dto.InviteResponseDto;
import com.saleex.admin.user.dto.AuthUserDto;

public interface InvitationService {

    InviteResponseDto inviteByAdmin(Long id, InviteRequestDto user);

    String confirmInvitee(AuthUserDto user);

    Long createUserFormInvite(AuthUserDto request);

}
