package com.saleex.admin.product.dto;

import java.math.BigDecimal;
import java.util.List;


import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class AddProductRequestDto {
    @NotBlank(message = "Product name is required")
    @Size(max = 255, message = "Product name cannot be longer than 255 characters")
    private String productName;

    @Size(max = 255, message = "Description cannot be longer than 255 characters")
    private String description;

    @PositiveOrZero(message = "Quantity must be a positive or zero value")
    private int quantity;

    @Positive(message = "Price must be a positive value")
    private BigDecimal price;

    private List<String> picture;

    @Positive(message = "Added by user ID must be a positive value")
    private long addedByUserId;
}