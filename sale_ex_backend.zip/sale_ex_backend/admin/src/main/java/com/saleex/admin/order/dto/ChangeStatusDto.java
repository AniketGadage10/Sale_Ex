package com.saleex.admin.order.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class ChangeStatusDto {
    private Long id;

    private String status;

}
