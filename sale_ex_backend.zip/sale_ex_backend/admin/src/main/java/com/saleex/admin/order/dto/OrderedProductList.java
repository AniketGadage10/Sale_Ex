package com.saleex.admin.order.dto;

import java.math.BigDecimal;
import java.util.List;

import com.saleex.admin.product.dto.AddProductResponseDto;
import com.saleex.admin.user.dto.UserResponseDto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class OrderedProductList {

    private Long id;

    private List<AddProductResponseDto> orderedProduct;

    private BigDecimal total_amount;

    private String status;

    private UserResponseDto seller;

    private UserResponseDto customer;

    private Date orderDate;

}
