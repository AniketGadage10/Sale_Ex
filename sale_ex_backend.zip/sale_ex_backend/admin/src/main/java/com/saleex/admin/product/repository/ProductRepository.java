package com.saleex.admin.product.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.saleex.admin.common.enums.ProductType;
import com.saleex.admin.product.entity.Product;

import java.util.List;

public interface ProductRepository extends JpaRepository<Product, Long> {

    Page<Product> findByProductType(ProductType productType, Pageable pageable);

    @Query("SELECT p FROM Product p ORDER BY (p.fixedQuantity - p.quantity) DESC")
    List<Product> findTop5ByOrderBySoldQuantityDesc();

    @Query("SELECT p FROM Product p WHERE LOWER(p.productName) LIKE LOWER(CONCAT('%', :name, '%'))")
    Page<Product> findByNameWithPagination(@Param("name") String name, Pageable pageable);

    @Query(nativeQuery = true, value = "SELECT * FROM products " +
            "WHERE creation_date BETWEEN CURRENT_DATE - INTERVAL '7 days' AND CURRENT_DATE " +
            "ORDER BY (fixed_quantity - quantity) DESC " +
            "LIMIT 6")
    List<Product> findTop5ByQuantityComparisonForLast7Days();

    @Query("SELECT p FROM Product p WHERE p.status = com.saleex.admin.common.enums.EntityStatus.ACTIVE")
    Page<Product> findAllActiveProducts(Pageable pageable);

}
