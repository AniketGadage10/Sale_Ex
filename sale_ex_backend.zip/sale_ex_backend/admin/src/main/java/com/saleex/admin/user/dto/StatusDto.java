package com.saleex.admin.user.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StatusDto {
    private String status;
    private Long id;
    private String email;
}
