// package com.saleex.admin.user.repository;

// import org.springframework.data.jpa.repository.JpaRepository;

// import com.saleex.admin.entity.Address;

// public interface AddressRepository extends JpaRepository<Address, Long> {

// }
