package com.saleex.admin.order.orderProduct.repository;

import java.util.Optional;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;

import com.saleex.admin.order.entity.Order;
import com.saleex.admin.order.entity.OrderProducts;
import com.saleex.admin.product.entity.Product;

public interface ProductOrderRepository extends JpaRepository<OrderProducts, Long> {

    Optional<OrderProducts> findByOrderAndProduct(Order order, Product product);

    void deleteByOrderAndProductNotIn(Order order, Set<Long> keySet);

}
