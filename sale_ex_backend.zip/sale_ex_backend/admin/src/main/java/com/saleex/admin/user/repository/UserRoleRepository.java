package com.saleex.admin.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.saleex.admin.user.entity.UserRole;

public interface UserRoleRepository extends JpaRepository<UserRole, Long> {

}