package com.saleex.admin.user.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.saleex.admin.auth.jwt.filter.JwtService;
import com.saleex.admin.auth.jwt.token.RequestToken;
import com.saleex.admin.auth.jwt.token.TokenDto;
import com.saleex.admin.common.enums.EntityStatus;
import com.saleex.admin.common.exception.NotFoundException;
import com.saleex.admin.invitation.dto.InviteRequestDto;
import com.saleex.admin.invitation.entity.Invitation;
import com.saleex.admin.invitation.repository.InvitationRepository;
import com.saleex.admin.invitation.service.InvitationService;
import com.saleex.admin.notification.entity.Notification;
import com.saleex.admin.notification.repository.NotificationRepository;
import com.saleex.admin.user.dto.AdminDto;
import com.saleex.admin.user.dto.AuthUserDto;
import com.saleex.admin.user.dto.CustomerResponseDto;
import com.saleex.admin.user.dto.StatusDto;
import com.saleex.admin.user.dto.UserFullDetails;
import com.saleex.admin.user.dto.UserRequestDto;
import com.saleex.admin.user.dto.UserResponseDto;
import com.saleex.admin.user.entity.Role;
import com.saleex.admin.user.entity.User;
import com.saleex.admin.user.entity.UserRole;
import com.saleex.admin.user.repository.RoleRepository;
import com.saleex.admin.user.repository.UserRepository;
import com.saleex.admin.user.repository.UserRoleRepository;
import java.nio.charset.StandardCharsets;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserRepository userRepo;

    @Autowired
    private ModelMapper mapper;

    @Autowired
    private RoleRepository roleRepo;

    @Autowired
    private UserRoleRepository userRoleRepo;


    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private NotificationRepository notificationRepo;

    @Autowired
    private InvitationRepository invitationRepo;

    @Autowired
    private InvitationService invitationService;

    @Autowired
    private InvitationRepository inviteeRepo;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Transactional
    @Override
    public UserResponseDto createUser(AdminDto user) throws IOException {
        User newUser = mapper.map(user, User.class);
        newUser.setPassword(passwordEncoder.encode(user.getPassword()));
        Role role = roleRepo.findByName(user.getRole().toUpperCase());
        if (role == null) {
            throw new NotFoundException(user.getRole() + "role is not valid");
        }

        UserRole userRole = userRoleRepo.save(new UserRole(newUser, role));
        Set<UserRole> roleList = new HashSet<>();
        roleList.add(userRole);
        byte[] fileBytes = user.getUserProfile().getBytes();
        newUser.setUserProfile(fileBytes);
        newUser.setUserRoles(roleList);
        newUser.setStatus(EntityStatus.ACTIVE);
        newUser.setInvitedBy(1L);
        User userDetails = userRepo.save(newUser);
        UserResponseDto userResponse = mapper.map(userDetails, UserResponseDto.class);
        userDetails.getUserRoles().stream().forEach((e) -> userResponse.setRole(e.getRole().getName()));
        if (userDetails.getUserProfile() == null) {
            userResponse.setUserProfile("Image not available");
        } else {
            userResponse.setUserProfile(new String(userDetails.getUserProfile(), StandardCharsets.UTF_8));
        }
        userResponse.setStatus(userDetails.getStatus().name());

        return userResponse;
    }

    @Transactional
    @Override
    public UserResponseDto updateUser(Long id, UserRequestDto user) throws IOException {
        User currentUser = userRepo.findById(id)
                .orElseThrow(() -> new NotFoundException("User with id:" + id + " not found !"));
        if (currentUser.getStatus() == EntityStatus.DEACTIVATE) {
            throw new NotFoundException("User not found or has been deleted or has been deleted");
        }

        if (user == null || user.getFname() == null || user.getLname() == null
                || user.getEmail() == null) {
            throw new NotFoundException("Invalid credentials. Please check");
        }

        currentUser.setInvitedBy(id);
        currentUser.setFname(user.getFname());
        currentUser.setLname(user.getLname());
        currentUser.setEmail(user.getEmail());
        currentUser.setContact(user.getContact());
        currentUser.setAddress(user.getAddress());
        if (user.getPassword() == null) {
            currentUser.setPassword(currentUser.getPassword());
        } else {
            currentUser.setPassword(passwordEncoder.encode(user.getPassword()));
        }

        if (user.getUserProfile() == null) {
            currentUser.setUserProfile(currentUser.getUserProfile());
        } else {
            byte[] fileBytes = user.getUserProfile().getBytes();
            currentUser.setUserProfile(fileBytes);

        }
        currentUser.setStatus(EntityStatus.ACTIVE);
        currentUser.setUpdationDate(new Date());

        currentUser.getUserRoles().stream()
                .forEach((e) -> System.out.println("---------" + e.getRole().getName() + "-----------------"));

        userRepo.save(currentUser);
        UserResponseDto userResponse = mapper.map(currentUser, UserResponseDto.class);
        currentUser.getUserRoles().stream().forEach((e) -> userResponse.setRole(e.getRole().getName()));
        if (currentUser.getUserProfile() == null) {
            userResponse.setUserProfile("Image not available");
        } else {
            userResponse.setUserProfile(new String(currentUser.getUserProfile(), StandardCharsets.UTF_8));
        }
        userResponse.setStatus(currentUser.getStatus().name());
        return userResponse;
    }

    @Transactional
    @Override
    public UserResponseDto deleteUser(Long id) {
        User currentUser = userRepo.findById(id)
                .orElseThrow(() -> new NotFoundException("User with id:" + id + " not found !"));
        if (currentUser.getStatus() == EntityStatus.DEACTIVATE) {
            throw new NotFoundException("User not found or has been deleted or has been deleted");
        }
        currentUser.setStatus(EntityStatus.DEACTIVATE);
        UserResponseDto userResponse = mapper.map(currentUser, UserResponseDto.class);
        currentUser.getUserRoles().stream().forEach((e) -> userResponse.setRole(e.getRole().getName()));
        if (currentUser.getUserProfile() == null) {
            userResponse.setUserProfile("Image not available");
        } else {
            userResponse.setUserProfile(new String(currentUser.getUserProfile(), StandardCharsets.UTF_8));
        }
        userResponse.setStatus(currentUser.getStatus().name());
        return userResponse;
    }

    @Override
    public UserFullDetails getUserById(Long id) {
        User currentUser = userRepo.findById(id)
                .orElseThrow(() -> new NotFoundException("User with id:" + id + " not found !"));
        if (currentUser.getStatus() == EntityStatus.DEACTIVATE) {
            throw new NotFoundException("User not found or has been deleted or has been deleted");
        }

        UserFullDetails userResponse = mapper.map(currentUser, UserFullDetails.class);
        currentUser.getUserRoles().stream().forEach((e) -> userResponse.setRole(e.getRole().getName()));
        if (currentUser.getUserProfile() == null) {
            userResponse.setUserProfile("Image not available");
        } else {
            userResponse.setUserProfile(new String(currentUser.getUserProfile(), StandardCharsets.UTF_8));
        }
        userResponse.setStatus(currentUser.getStatus().name());
        return userResponse;
    }

    @Transactional
    @Override
    public List<UserResponseDto> listOfUsers() {
        List<User> userList = userRepo.findAll();
        List<UserResponseDto> userResponseList = new ArrayList<>();
        for (User user : userList) {

            if (user.getStatus() == EntityStatus.DEACTIVATE) {
                throw new NotFoundException("User not found or has been deleted or has been deleted");
            }

            UserResponseDto userResponse = mapper.map(user, UserResponseDto.class);
            user.getUserRoles().stream().forEach((e) -> userResponse.setRole(e.getRole().getName()));
            if (user.getUserProfile() == null) {
                userResponse.setUserProfile("Image not available");
            } else {
                userResponse.setUserProfile(new String(user.getUserProfile(), StandardCharsets.UTF_8));
            }
            userResponse.setStatus(user.getStatus().name());
            userResponseList.add(userResponse);
        }
        Collections.sort(userResponseList, new Comparator<UserResponseDto>() {
            @Override
            public int compare(UserResponseDto user1, UserResponseDto user2) {
                Date date1 = user1.getJoiningDate();
                Date date2 = user2.getJoiningDate();
                return date1.compareTo(date2);
            }
        });

        return userResponseList;
    }

    @Transactional
    @Override
    public TokenDto userLogin(@Valid AuthUserDto dto) {
        boolean inviteeExists = inviteeRepo.findByInviteeEmailAndPassword(dto.getEmail(), dto.getPassword())
                .isPresent();

        if (inviteeExists) {
            Invitation invitee = inviteeRepo.findByInviteeEmailAndPassword(dto.getEmail(), dto.getPassword())
                    .orElseThrow(() -> new NotFoundException("User not found or has been deleted or has been deleted"));
            User user = new User();

            if (invitee == null || invitee.getFName() == null || invitee.getLName() == null
                    || invitee.getInviteeEmail() == null || invitee.getPassword() == null) {
                throw new NotFoundException("Invalid invitee data");
            }

            user.setInvitedBy(invitee.getInviter().getId());
            user.setFname(invitee.getFName());
            user.setLname(invitee.getLName());
            user.setEmail(invitee.getInviteeEmail());
            user.setPassword(passwordEncoder.encode(invitee.getPassword()));
            user.setStatus(EntityStatus.INVITED);
            user.setContact("Not Provided");
            user.setAddress("Not Provided");
            Set<UserRole> set = new HashSet<>();
            UserRole userRole = new UserRole(user,
                    roleRepo.findByName(invitee.getInviteeRole()));
            set.add(userRole);

            userRoleRepo.save(userRole);
            user.setUserRoles(set);

            if (user.getNotifications() == null) {
                user.setNotifications(new ArrayList<>());
            }

            User savedUser = userRepo.save(user);

            Notification notifyUser;

            if (savedUser.getNotifications().isEmpty()) {
                notifyUser = new Notification();
                notifyUser.setFirebaseToken(dto.getFirebaseToken());
                notifyUser.setUser(savedUser);
            } else {
                notifyUser = savedUser.getNotifications().get(0);
                notifyUser.setFirebaseToken(savedUser.getNotifications().get(0).getFirebaseToken());
                notifyUser.setUser(savedUser);
            }

            notificationRepo.save(notifyUser);

            savedUser.getNotifications().add(notifyUser);

            userRepo.save(savedUser);

            invitationRepo.delete(invitee);

            TokenDto tokenDto = new TokenDto();

            User logUser = userRepo.findByEmail(dto.getEmail()).get(0);

            UserResponseDto userResp = convertUserToUserRespone(logUser);

            tokenDto.setUser(userResp);

            return tokenDto;

        } else {
            return login(dto);
        }
    }

    @Transactional
    public TokenDto login(@Valid AuthUserDto dto) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(dto.getEmail(), dto.getPassword()));

            if (authentication.isAuthenticated()) {
                UserDetails userDetails = (UserDetails) authentication.getPrincipal();
                String accessToken = jwtService.generateToken(userDetails);
                String refreshToken = jwtService.generateRefereshToken(userDetails);
                TokenDto tokenDto = new TokenDto();

                tokenDto.setAccessToken(accessToken);

                tokenDto.setRefreshToken(refreshToken);

                User user = userRepo.findByEmail(dto.getEmail()).get(0);

                UserResponseDto userResp = convertUserToUserRespone(user);

                if (user.getNotifications() == null) {
                    user.setNotifications(new ArrayList<>());
                }

                User savedUser = userRepo.save(user);

                Notification notifyUser;

                if (savedUser.getNotifications().isEmpty()) {
                    notifyUser = new Notification();
                    notifyUser.setFirebaseToken(dto.getFirebaseToken());
                    notifyUser.setUser(savedUser);
                } else {
                    notifyUser = savedUser.getNotifications().get(0);
                    notifyUser.setFirebaseToken(dto.getFirebaseToken());
                    notifyUser.setUser(savedUser);
                }

                notificationRepo.save(notifyUser);

                savedUser.getNotifications().add(notifyUser);

                tokenDto.setUser(userResp);
                return tokenDto;
            } else {
                throw new NotFoundException("Authentication failed");
            }
        } catch (

        NotFoundException e) {
            String errorMessage = "Invalid credentials. Please check your email and password.";
            throw new NotFoundException(errorMessage);
        }
    }

    @Override
    public String generateTokenFromRefreshToken(RequestToken refreshToken) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null) {
            String userDetails = (String) authentication.getPrincipal();
            if (jwtService.isValidRefreshToken(refreshToken, userDetails)) {
                String newAccessToken = jwtService.generateTokenbyBareEmail(userDetails);
                return newAccessToken;
            } else {

                throw new NotFoundException("Invalid refresh token");
            }
        } else {
            throw new NotFoundException("User is not  authenticated");

        }
    }


    @Override
    public Page<UserResponseDto> filterByDate(Date startDate, Date endDate, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<User> userPage = userRepo.findByJoiningDates(startDate, endDate, pageable);

        if (userPage.isEmpty()) {
            throw new NotFoundException("No users found within the specified date range.");
        }

        List<UserResponseDto> userResponseList = new ArrayList<>();

        for (User user : userPage) {
            UserResponseDto userResponse = mapper.map(user, UserResponseDto.class);
            user.getUserRoles().forEach(e -> userResponse.setRole(e.getRole().getName()));
            if (user.getUserProfile() == null) {
                userResponse.setUserProfile("Image not available");
            } else {
                userResponse.setUserProfile(new String(user.getUserProfile(), StandardCharsets.UTF_8));
            }
            userResponseList.add(userResponse);
        }

        return new PageImpl<>(userResponseList, pageable, userPage.getTotalElements());
    }

    @Override
    public Page<UserResponseDto> findEntitiesByNameWithPagination(String name, int page, int size) {
        PageRequest pageRequest = PageRequest.of(page, size);
        Page<User> userPage = userRepo.findByUsernameWithPagination(name, pageRequest);
        List<UserResponseDto> userResponseList = new ArrayList<>();
        for (User user : userPage) {
            UserResponseDto userResponse = mapper.map(user, UserResponseDto.class);
            user.getUserRoles().forEach(e -> userResponse.setRole(e.getRole().getName()));
            if (user.getUserProfile() == null) {
                userResponse.setUserProfile("Image not available");
            } else {
                userResponse.setUserProfile(new String(user.getUserProfile(), StandardCharsets.UTF_8));
            }
            userResponseList.add(userResponse);
        }
        return new PageImpl<>(userResponseList, pageRequest, userPage.getTotalElements());

    }

    @Override
    public Page<UserResponseDto> filterByRoles(String role, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<User> userPage = userRepo.findByRoleName(role.toUpperCase(), pageable);

        if (userPage.isEmpty()) {
            throw new NotFoundException("No users found with the role: " + role);
        }

        List<UserResponseDto> userResponseList = new ArrayList<>();

        for (User user : userPage) {
            UserResponseDto userResponse = mapper.map(user, UserResponseDto.class);

            if (!user.getStatus().equals(EntityStatus.DEACTIVATE)) {
                user.getUserRoles().forEach(e -> userResponse.setRole(e.getRole().getName()));

                if (user.getUserProfile() == null) {
                    userResponse.setUserProfile("Image not available");
                } else {
                    userResponse.setUserProfile(new String(user.getUserProfile(), StandardCharsets.UTF_8));
                }
                userResponse.setStatus(user.getStatus().name());
                userResponseList.add(userResponse);
            }
        }

        return new PageImpl<>(userResponseList, pageable, userPage.getTotalElements());
    }

    @Override
    public Page<CustomerResponseDto> customerList(int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<User> userPage = userRepo.findByRoleName("CUSTOMER", pageable);

        if (userPage.isEmpty()) {
            throw new NotFoundException("No users found with the role: " + "Customer");
        }

        List<CustomerResponseDto> userResponseList = new ArrayList<>();

        for (User user : userPage) {

            CustomerResponseDto userResponse = mapper.map(user, CustomerResponseDto.class);

            User seller = userRepo.findById(user.getInvitedBy())
                    .orElseThrow(() -> new NotFoundException("Seller not found"));
            UserResponseDto sellerDetails = mapper.map(seller,
                    UserResponseDto.class);
            seller.getUserRoles().forEach(e -> sellerDetails.setRole(e.getRole().getName()));

            userResponse.setSeller(sellerDetails);

            if (!user.getStatus().equals(EntityStatus.DEACTIVATE) && !user.getStatus()
                    .equals(EntityStatus.INVITED)) {
                user.getUserRoles().forEach(e -> userResponse.setRole(e.getRole().getName()));

                if (user.getUserProfile() == null) {
                    userResponse.setUserProfile("Image not available");
                } else {
                    userResponse.setUserProfile(new String(user.getUserProfile(), StandardCharsets.UTF_8));
                }
                userResponse.setStatus(user.getStatus().name());
                userResponseList.add(userResponse);
            }
        }

        return new PageImpl<>(userResponseList, pageable, userPage.getTotalElements());
    }

    @Override
    @Transactional
    public Page<UserResponseDto> filterForCustomer(String name, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<User> userPage = userRepo.findCustomersByName(name, pageable);

        if (userPage.isEmpty()) {
            throw new NotFoundException("No users found with the role: ");
        }

        List<UserResponseDto> userResponseList = new ArrayList<>();

        for (User user : userPage) {
            UserResponseDto userResponse = mapper.map(user, UserResponseDto.class);

            if (!user.getStatus().equals(EntityStatus.DEACTIVATE)) {
                user.getUserRoles().forEach(e -> userResponse.setRole(e.getRole().getName()));
                if (user.getUserProfile() == null) {
                    userResponse.setUserProfile("Image not available");
                } else {
                    userResponse.setUserProfile(new String(user.getUserProfile(), StandardCharsets.UTF_8));
                }
                userResponse.setStatus(user.getStatus().name());
                userResponseList.add(userResponse);
            }
        }

        return new PageImpl<>(userResponseList, pageable, userPage.getTotalElements());
    }

    @Transactional
    @Override
    public Page<UserResponseDto> listOfUsersByPagination(Integer pageNumber, Integer pageSize) {
        Pageable page = PageRequest.of(pageNumber, pageSize);
        Page<User> userPage = userRepo.findAll(page);
        Page<Invitation> inviteePage = inviteeRepo.findAll(page);

        if (userPage.isEmpty() && inviteePage.isEmpty()) {
            throw new NotFoundException("No users or invitations found.");
        }

        List<UserResponseDto> userResponseList = new ArrayList<>();


        for (User user : userPage) {

            UserResponseDto userResponse = convertUserToUserRespone(user);
            userResponseList.add(userResponse);
        }

        return new PageImpl<>(userResponseList, page, userResponseList.size());

    }

    @Transactional
    @Override
    public Page<UserResponseDto> listOfUserByStatus(Integer pageNumber, Integer pageSize, String status) {
        Pageable page = PageRequest.of(pageNumber, pageSize);
        Page<User> userPage = userRepo.findByStatus(EntityStatus.valueOf(status), page);

        if (userPage.isEmpty()) {
            throw new NotFoundException("No users found.");
        }

        List<UserResponseDto> userResponseList = new ArrayList<>();

        for (User user : userPage) {
            UserResponseDto userResponse = convertUserToUserRespone(user);
            userResponseList.add(userResponse);
        }

        return new PageImpl<>(userResponseList, page, userPage.getTotalElements());
    }

    private UserResponseDto convertUserToUserRespone(User user) {
        UserResponseDto userResponse = mapper.map(user, UserResponseDto.class);
        user.getUserRoles().forEach(e -> userResponse.setRole(e.getRole().getName()));
        if (user.getUserProfile() == null) {
            userResponse.setUserProfile("Image not available");
        } else {
            userResponse.setUserProfile(new String(user.getUserProfile(), StandardCharsets.UTF_8));
        }
        userResponse.setStatus(user.getStatus().name());
        return userResponse;
    }

    @Override
    public StatusDto changeStatus(String status, Long id) {
        User user = null;
        Invitation invitee = null;

        if ("CANCEL".equals(status)) {
            user = userRepo.findById(id)
                    .orElseThrow(() -> new EntityNotFoundException("User not found with id: " + id));
            deleteUser(id);
            return convertToStatusDto(user, null);
        }

        EntityStatus stat = EntityStatus.valueOf(status);

        if (EntityStatus.INVITED.equals(stat)) {
            user = userRepo.findById(id).orElse(null);

            if (user == null) {
                invitee = invitationRepo.findById(id)
                        .orElseThrow(() -> new EntityNotFoundException("Invitation not found with id: " + id));

                invitationRepo.delete(invitee);
                User invitor = invitee.getInviter();
                invitationService.inviteByAdmin(invitor.getId(), convertorIvitationToDto(invitee));
                return convertToStatusDto(null, invitee);
            } else {
                user.getUserRoles().forEach(userRoleRepo::delete);
                user.getNotifications().forEach(notificationRepo::delete);
                userRepo.delete(user);
                invitationService.inviteByAdmin(user.getInvitedBy(), convertorToUserDto(user));
                return convertToStatusDto(user, null);
            }
        } else if (EntityStatus.DEACTIVATE.equals(stat)) {
            user = userRepo.findById(id)
                    .orElseThrow(() -> new EntityNotFoundException("User not found with id: " + id));
            user.setStatus(EntityStatus.ACTIVE);
        } else {
            user = userRepo.findById(id)
                    .orElseThrow(() -> new EntityNotFoundException("User not found with id: " + id));
            user.setStatus(EntityStatus.DEACTIVATE);
        }

        return convertToStatusDto(userRepo.save(user), null);
    }

    private InviteRequestDto convertorIvitationToDto(Invitation invitation) {
        InviteRequestDto dto = new InviteRequestDto();
        dto.setFName(invitation.getFName());
        dto.setInviteeEmail(invitation.getInviteeEmail());
        dto.setLName(invitation.getLName());
        dto.setInviteeRole(invitation.getInviteeRole());
        return dto;
    }

    private InviteRequestDto convertorToUserDto(User invitation) {
        InviteRequestDto dto = new InviteRequestDto();
        dto.setFName(invitation.getFname());
        dto.setInviteeEmail(invitation.getEmail());
        dto.setLName(invitation.getLname());
        invitation.getUserRoles().forEach(e -> dto.setInviteeRole(e.getRole().getName()));
        return dto;
    }

    private StatusDto convertToStatusDto(User user, Invitation invitation) {
        StatusDto status = new StatusDto();
        if (user == null) {
            status.setEmail(invitation.getInviteeEmail());
            status.setId(invitation.getId());
            status.setStatus(invitation.getStatus().name());
            return status;
        } else {
            status.setEmail(user.getEmail());
            status.setId(user.getId());
            status.setStatus(user.getStatus().name());
            return status;
        }
    }

}