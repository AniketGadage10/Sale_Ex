package com.saleex.admin.common.enums;

public enum InvitationEnum {
    PENDING, ACCEPTED;
}
