package com.saleex.admin.common.response;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class HttpResposne<T> {
    private Integer code;

    private String message;

    private T data;

    private Date timestamp;
}
