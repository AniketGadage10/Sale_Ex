package com.saleex.admin.order.orderService;

import java.util.List;

import org.springframework.data.domain.Page;

import com.saleex.admin.order.dto.ActiveOrderDetails;
import com.saleex.admin.order.dto.AllOrderDetails;
import com.saleex.admin.order.dto.ChangeStatusDto;
import com.saleex.admin.order.dto.OrderRequestDto;
import com.saleex.admin.order.dto.OrderResponseDto;
import com.saleex.admin.order.dto.OrderedProductList;

public interface OrderService {
    AllOrderDetails createOrder(Long seller_id, OrderRequestDto orderDetails);

    AllOrderDetails updateOrder(Long id, Long sellerId, OrderRequestDto orderDetails);

    OrderResponseDto deleteOrder(Long id);

    OrderedProductList getOrderbyId(Long id);

    List<OrderedProductList> orderedProductList();

    Page<OrderedProductList> ordersByStatus(String status, int page, int size);

    ActiveOrderDetails orderDetails();

    Page<AllOrderDetails> filterProductsById(Long id, int pageNumber, int pageSize);

    AllOrderDetails changeOrderStatus(ChangeStatusDto statusDetails);

    

}
