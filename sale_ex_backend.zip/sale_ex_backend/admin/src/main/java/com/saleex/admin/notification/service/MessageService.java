package com.saleex.admin.notification.service;

import com.saleex.admin.notification.dto.NotificationListDto;
import java.util.*;

public interface MessageService {
    List<NotificationListDto> getNotificationList(Long id);

}
