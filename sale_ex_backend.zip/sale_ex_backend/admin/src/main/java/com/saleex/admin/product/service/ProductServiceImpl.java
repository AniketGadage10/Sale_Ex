package com.saleex.admin.product.service;

import java.math.RoundingMode;
import java.util.*;
import java.nio.charset.StandardCharsets;
import org.springframework.data.domain.PageImpl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.saleex.admin.common.enums.EntityStatus;
import com.saleex.admin.common.enums.ProductType;
import com.saleex.admin.common.exception.NotFoundException;
import com.saleex.admin.product.dto.AddProductRequestDto;
import com.saleex.admin.product.dto.AddProductResponseDto;
import com.saleex.admin.product.dto.ProductDto;
import com.saleex.admin.product.dto.ProductDtoForMobile;
import com.saleex.admin.product.entity.Product;
import com.saleex.admin.product.repository.ProductRepository;
import com.saleex.admin.user.entity.User;
import com.saleex.admin.user.repository.UserRepository;

import jakarta.transaction.Transactional;

@Service
public class ProductServiceImpl implements ProductService {

    private final ProductRepository productRepository;
    private final UserRepository userRepository;

    @Autowired
    ModelMapper modelMapper;

    public ProductServiceImpl(ProductRepository productRepository, UserRepository userRepository) {
        this.productRepository = productRepository;
        this.userRepository = userRepository;

    }

    @Override
    public AddProductResponseDto addProduct(AddProductRequestDto product) {

        Product newProduct = new Product();

        User addedUser = userRepository.findById(product.getAddedByUserId())
                .orElseThrow(() -> new NotFoundException("User not found or has been deleted"));

        newProduct.setProductName(product.getProductName());
        newProduct.setDescription(product.getDescription());
        newProduct.setQuantity(product.getQuantity());
        newProduct.setStatus(EntityStatus.ACTIVE);
        newProduct.setFixedQuantity(product.getQuantity());
        newProduct.setPrice(product.getPrice().setScale(3, RoundingMode.DOWN));
        List<byte[]> listOfProductPicture = new ArrayList<>();

        for (String productPicture : product.getPicture()) {
            listOfProductPicture.add(productPicture.getBytes());
        }
        newProduct.setPicture(listOfProductPicture);
        newProduct.setProductType(ProductType.ACCESSORIES);
        newProduct.setAddedBy(addedUser);

        Product savedProduct = productRepository.save(newProduct);

        AddProductResponseDto response = modelMapper.map(savedProduct, AddProductResponseDto.class);
        List<String> listOfPicture = new ArrayList<>();

        for (byte[] arr : savedProduct.getPicture()) {
            listOfPicture.add(new String(arr, StandardCharsets.UTF_8));
        }

        response.setPicture(listOfPicture);

        return response;
    }

    @Override
    public ProductDto deleteProduct(Long id) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Product unavailable"));
        checkProductStatus(product);
        if (product != null && !product.getStatus().equals(EntityStatus.DEACTIVATE)) {
            product.setStatus(EntityStatus.DEACTIVATE);
            productRepository.save(product);
            ProductDto response = modelMapper.map(product, ProductDto.class);

            List<String> listOfPicture = new ArrayList<>();

            for (byte[] arr : product.getPicture()) {
                listOfPicture.add(new String(arr, StandardCharsets.UTF_8));
            }
            response.setPicture(listOfPicture);

            return response;
        } else {
            throw new NoSuchElementException("Product unavailable with ID: " + id);
        }
    }

    @Override
    public ProductDto getProductById(Long productId) {

        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new NotFoundException("Product unavailable"));

        checkProductStatus(product);
        if (product != null) {
            ProductDto response = modelMapper.map(product, ProductDto.class);
            List<String> listOfPicture = new ArrayList<>();

            for (byte[] arr : product.getPicture()) {
                listOfPicture.add(new String(arr, StandardCharsets.UTF_8));
            }

            response.setPicture(listOfPicture);

            return response;
        } else {
            throw new NoSuchElementException("Product unavailable with ID: " + productId);
        }
    }

    @Override
    public Page<ProductDto> getAllProducts(Pageable pageable) {
        if (pageable == null) {
            pageable = PageRequest.of(0, 10, Sort.by("productName").ascending());
        }

        Page<Product> productList = productRepository.findAllActiveProducts(pageable);

        List<ProductDto> responseList = new ArrayList<>();

        for (Product product : productList) {
            List<String> listOfPicture = new ArrayList<>();

            for (byte[] arr : product.getPicture()) {
                listOfPicture.add(new String(arr, StandardCharsets.UTF_8));
            }

            ProductDto data = modelMapper.map(product, ProductDto.class);
            data.setPicture(listOfPicture);
            responseList.add(data);

        }

        return new PageImpl<>(responseList, pageable, productList.getTotalElements());
    }

    @Override
    public ProductDto updateProduct(Long productId, AddProductRequestDto updateProductRequestDto) {
        // Check if the product with the given ID exists
        Product existingProduct = productRepository.findById(productId)
                .orElseThrow(() -> new NotFoundException("Product with ID " + productId + " not found"));
        checkProductStatus(existingProduct);
        // Update only the non-null fields from the request
        if (updateProductRequestDto.getProductName() != null) {
            existingProduct.setProductName(updateProductRequestDto.getProductName());
        }
        if (updateProductRequestDto.getDescription() != null) {
            existingProduct.setDescription(updateProductRequestDto.getDescription());
        }
        if (updateProductRequestDto.getQuantity() != 0) {
            existingProduct.setQuantity(updateProductRequestDto.getQuantity());
            existingProduct.setFixedQuantity(updateProductRequestDto.getQuantity());
        }
        if (updateProductRequestDto.getPrice() != null) {
            existingProduct.setPrice(updateProductRequestDto.getPrice().setScale(3, RoundingMode.DOWN));
        }
        if (updateProductRequestDto.getPicture() != null) {
            List<byte[]> pictureList = new ArrayList<>();
            for (String productPicture : updateProductRequestDto.getPicture()) {

                pictureList.add(productPicture.getBytes());
            }
            existingProduct.setPicture(pictureList);
        }

        Product updatedProduct = productRepository.save(existingProduct);

        List<String> listOfPicture = new ArrayList<>();

        for (byte[] arr : updatedProduct.getPicture()) {
            listOfPicture.add(new String(arr, StandardCharsets.UTF_8));
        }

        return new ProductDto(updatedProduct.getId(), updatedProduct.getProductName(),
                updatedProduct.getDescription(), updatedProduct.getQuantity(),
                updatedProduct.getPrice().setScale(3,
                        RoundingMode.DOWN),
                listOfPicture,
                updatedProduct.getProductType(), updatedProduct.getAddedBy().getId());
    }

    @Override
    public Page<ProductDto> getProductsByType(ProductType productType, Pageable pageable) {
        if (productType == null) {
            throw new IllegalArgumentException("Please enter valid product type");
        }

        // Sort sort =
        Sort.by("productName").ascending();

        Page<Product> productsPage = productRepository.findByProductType(productType, pageable);

        List<ProductDto> responseList = new ArrayList<>();

        for (Product product : productsPage) {

            List<String> listOfPicture = new ArrayList<>();
            if (product.getStatus().equals(EntityStatus.DEACTIVATE)) {
                continue;
            } else {
                for (byte[] arr : product.getPicture()) {
                    listOfPicture.add(new String(arr, StandardCharsets.UTF_8));
                }

                ProductDto data = modelMapper.map(product, ProductDto.class);
                data.setPicture(listOfPicture);
                responseList.add(data);
            }

        }

        return new PageImpl<>(responseList, pageable, productsPage.getTotalElements());
    }

    @Override
    @Transactional
    public Page<AddProductResponseDto> filterProductsByName(String name, int pageNumber, int sizeNumber) {
        Pageable pageable = PageRequest.of(pageNumber, sizeNumber);
        Page<Product> productsPage = productRepository.findByNameWithPagination(name, pageable);

        List<AddProductResponseDto> responseList = new ArrayList<>();
        for (Product product : productsPage) {
            List<String> listOfPicture = new ArrayList<>();

            for (byte[] arr : product.getPicture()) {
                listOfPicture.add(new String(arr, StandardCharsets.UTF_8));
            }

            AddProductResponseDto data = modelMapper.map(product, AddProductResponseDto.class);
            data.setPicture(listOfPicture);
            responseList.add(data);

        }

        return new PageImpl<>(responseList, pageable, productsPage.getTotalElements());

    }

    public void checkProductStatus(Product product) {
        if (product.getStatus().equals(EntityStatus.DEACTIVATE)) {
            new NotFoundException("Product unavailable");
        }
    }

    @Override
    public ProductDtoForMobile productDetailsForMobile() {
        List<Product> productList = productRepository.findAll();
        Map<Long, String> list = new HashMap<>();
        for (Product detail : productList) {
            if (detail.getStatus().equals(EntityStatus.DEACTIVATE)) {
                continue;
            } else {
                list.put(detail.getId(), detail.getProductName());

            }
        }
        ProductDtoForMobile details = new ProductDtoForMobile();
        details.setProductDetails(list);
        ;
        return details;
    }
}
